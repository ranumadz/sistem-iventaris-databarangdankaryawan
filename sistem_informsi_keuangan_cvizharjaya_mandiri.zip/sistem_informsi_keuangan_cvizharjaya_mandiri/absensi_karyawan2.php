<?php
require 'cek-sesi.php';
require 'koneksi.php';
?>
<?php
include 'koneksi.php';

// Ambil minggu saat ini
$query = "SELECT * FROM absensi WHERE YEARWEEK(tanggal_masuk, 1) = YEARWEEK(NOW(), 1)";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Absensi Karyawan - Cv Izhar Jaya Mandiri</title>
    <link rel="icon" href="img/cv_izhar_jaya_mandiri.jpeg" type="image/x-icon">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito:200,300,400,600,700,800,900" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <style>
        .modal-header {
            background-color: #4e73df;
            color: white;
        }

        .modal-footer .btn-success {
            background-color: #28a745;
        }

        .modal-footer .btn-default {
            background-color: #6c757d;
            color: white;
        }

        .btn-custom {
            background-color: #4e73df;
            color: white;
        }

        .btn-custom:hover {
            background-color: #2e59d9;
            color: white;
        }
    </style>
</head>

<body id="page-top">
    <?php require 'sidebar2.php'; ?>

    <!-- Main Content -->
    <div id="content">
        <?php require 'navbar.php'; ?>

        <!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Header Section -->
            <div class="d-sm-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Absensi Karyawan</h1>
                <button type="button" class="btn btn-custom" data-toggle="modal" data-target="#myModalAbsenMasuk">
                    <i class="fa fa-calendar-check"></i> Tambah Absensi Masuk
                </button>
                <button type="button" class="btn btn-custom" data-toggle="modal" data-target="#myModalAbsenKeluar">
                    <i class="fa fa-calendar-times"></i> Tambah Absensi Keluar
                </button>
                <button type="button" class="btn btn-custom" data-toggle="modal" data-target="#myModalAbsenLembur">
                    <i class="fa fa-clock"></i> Tambah Absensi Lembur
                </button>
            </div>

            <!-- Filter Berdasarkan Bulan & Minggu -->
            <form method="GET" class="mb-4">
                <div class="row">
                    <div class="col-md-4">
                        <label for="filter_bulan">Pilih Bulan:</label>
                        <input type="month" name="filter_bulan" id="filter_bulan" class="form-control" value="<?= isset($_GET['filter_bulan']) ? $_GET['filter_bulan'] : date('Y-m') ?>">
                    </div>
                    <div class="col-md-4">
                        <label for="filter_minggu">Pilih Minggu:</label>
                        <input type="week" name="filter_minggu" id="filter_minggu" class="form-control" value="<?= isset($_GET['filter_minggu']) ? $_GET['filter_minggu'] : date('Y-\WW') ?>">
                    </div>
                    <div class="col-md-2">
                        <button type="submit" class="btn btn-primary mt-4">Tampilkan</button>
                    </div>
                </div>
            </form>

            <!-- Tabel Absensi -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Daftar Absensi</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID Karyawan</th>
                                    <th>Nama</th>
                                    <th>Tanggal</th>
                                    <th>Absensi Masuk</th>
                                    <th>Absensi Keluar</th>
                                    <th>Jam Lembur</th>
                                    <th>Absensi Lembur</th>
                                    <th>Keterangan</th> <!-- Kolom Keterangan -->
                                </tr>
                            </thead>
                            <tbody>
                                <?php
                                $filter_bulan = isset($_GET['filter_bulan']) ? $_GET['filter_bulan'] : date('Y-m');
                                $filter_minggu = isset($_GET['filter_minggu']) ? $_GET['filter_minggu'] : null;

                                $query = "SELECT absensi_karyawan.id_karyawan, karyawan.nama, absensi_karyawan.absen_masuk, absensi_karyawan.absen_keluar, 
                  absensi_karyawan.jam_lembur, absensi_karyawan.absen_lembur, absensi_karyawan.tanggal_masuk, absensi_karyawan.keterangan
                  FROM absensi_karyawan 
                  JOIN karyawan ON absensi_karyawan.id_karyawan = karyawan.id_karyawan 
                  WHERE DATE_FORMAT(absensi_karyawan.tanggal_masuk, '%Y-%m') = '$filter_bulan'";

                                if ($filter_minggu) {
                                    $tahun = substr($filter_minggu, 0, 4);
                                    $minggu = substr($filter_minggu, 6, 2);
                                    $query .= " AND WEEK(absensi_karyawan.tanggal_masuk, 1) = '$minggu' AND YEAR(absensi_karyawan.tanggal_masuk) = '$tahun'";
                                }

                                $result = mysqli_query($koneksi, $query);
                                while ($data = mysqli_fetch_assoc($result)) {
                                    echo "<tr>
                  <td>{$data['id_karyawan']}</td>
                  <td>{$data['nama']}</td>
                  <td>{$data['tanggal_masuk']}</td>
                  <td>{$data['absen_masuk']}</td>
                  <td>" . ($data['absen_keluar'] ?: '-') . "</td>
                  <td>" . ($data['jam_lembur'] ?: '-') . "</td>
                  <td>" . ($data['absen_lembur'] ?: '-') . "</td>
                  <td>{$data['keterangan']}</td> <!-- Tampilkan Keterangan -->
                </tr>";
                                }
                                ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>


            <!-- Modal Absensi Masuk -->
            <div id="myModalAbsenMasuk" class="modal fade" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Absensi Masuk</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <form action="tambah-absensi.php" method="post">
                            <div class="modal-body">
                                <!-- Pilih Karyawan -->
                                <div class="form-group">
                                    <label for="id_karyawan">Pilih Karyawan:</label>
                                    <select name="id_karyawan" id="id_karyawan" class="form-control" required>
                                        <?php
                                        $query_karyawan = mysqli_query($koneksi, "SELECT id_karyawan, nama FROM karyawan");
                                        while ($karyawan = mysqli_fetch_assoc($query_karyawan)) {
                                            echo '<option value="' . $karyawan['id_karyawan'] . '">' . $karyawan['nama'] . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>

                                <!-- Tanggal Masuk -->
                                <div class="form-group">
                                    <label for="tanggal_masuk">Tanggal Masuk:</label>
                                    <input type="date" id="tanggal_masuk" name="tanggal_masuk" class="form-control" required>
                                </div>

                                <!-- Absensi Masuk -->
                                <div class="form-group">
                                    <label for="absen_masuk">Absensi Masuk:</label>
                                    <input type="checkbox" id="absen_masuk" name="absen_masuk" value="Hadir">
                                </div>

                                <!-- Jam Masuk -->
                                <div class="form-group">
                                    <label for="jam_masuk">Jam Masuk:</label>
                                    <input type="time" id="jam_masuk" name="jam_masuk" class="form-control" required>
                                </div>
                            </div>

                            <div class="modal-footer">
                                <button type="submit" class="btn btn-success">Simpan</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Modal Absensi Keluar -->
            <div id="myModalAbsenKeluar" class="modal fade" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Absensi Keluar</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <form action="absensi_keluar.php" method="post">
                            <div class="modal-body">
                                <!-- Pilih Karyawan -->
                                <div class="form-group">
                                    <label for="id_karyawan">Pilih Karyawan:</label>
                                    <select name="id_karyawan" id="id_karyawan" class="form-control" required>
                                        <?php
                                        $query_karyawan = mysqli_query($koneksi, "SELECT id_karyawan, nama FROM karyawan");
                                        while ($karyawan = mysqli_fetch_assoc($query_karyawan)) {
                                            echo '<option value="' . $karyawan['id_karyawan'] . '">' . $karyawan['nama'] . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>

                                <!-- Absensi Keluar -->
                                <div class="form-group">
                                    <label for="absen_keluar">Absensi Keluar:</label>
                                    <input type="checkbox" id="absen_keluar" name="absen_keluar" value="Keluar">
                                </div>

                                <!-- Jam Keluar -->
                                <div class="form-group">
                                    <label for="jam_keluar">Jam Keluar:</label>
                                    <input type="time" id="jam_keluar" name="jam_keluar" class="form-control" required>
                                </div>
                            </div>

                            <div class="modal-footer">
                                <button type="submit" class="btn btn-success">Simpan</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <!-- Modal Absensi Lembur -->
            <div id="myModalAbsenLembur" class="modal fade" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Absensi Lembur</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <form action="absensi_lembur.php" method="post">
                            <div class="modal-body">
                                <!-- Pilih Karyawan -->
                                <div class="form-group">
                                    <label for="id_karyawan">Pilih Karyawan:</label>
                                    <select name="id_karyawan" id="id_karyawan" class="form-control" required>
                                        <?php
                                        include 'koneksi.php'; // Koneksi database
                                        $query_karyawan = mysqli_query($koneksi, "SELECT id_karyawan, nama FROM karyawan");
                                        while ($karyawan = mysqli_fetch_assoc($query_karyawan)) {
                                            echo '<option value="' . $karyawan['id_karyawan'] . '">' . $karyawan['nama'] . '</option>';
                                        }
                                        ?>
                                    </select>
                                </div>

                                <!-- Pilihan Lembur atau Tidak -->
                                <div class="form-group">
                                    <label>Apakah Karyawan Lembur?</label><br>
                                    <div class="form-check">
                                        <input type="radio" name="lembur" value="Ya" id="lembur_ya" class="form-check-input" required>
                                        <label class="form-check-label" for="lembur_ya">Ya</label>
                                    </div>
                                    <div class="form-check">
                                        <input type="radio" name="lembur" value="Tidak" id="lembur_tidak" class="form-check-input" required checked>
                                        <label class="form-check-label" for="lembur_tidak">Tidak</label>
                                    </div>
                                </div>

                                <!-- Lama Jam Lembur (Dropdown, muncul jika pilih "Ya") -->
                                <!-- Input Jam Lembur (Muncul Jika Pilih "Ya") -->
                                <div class="form-group" id="jamLemburSection" style="display: none;">
                                    <label for="jam_lembur">Jam Lembur:</label>
                                    <input type="time" name="jam_lembur" id="jam_lembur" class="form-control">
                                </div>
                                <!-- Input Keterangan -->
                                <div class="form-group">
                                    <label for="keterangan">Keterangan (Opsional):</label>
                                    <textarea name="keterangan" id="keterangan" class="form-control" rows="3" placeholder="Masukkan keterangan..."></textarea>
                                </div>

                                <div class="modal-footer">
                                    <button type="submit" class="btn btn-success">Simpan</button>
                                    <button type="button" class="btn btn-default" data-dismiss="modal">Tutup</button>
                                </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- Script untuk Menampilkan Dropdown Jam Lembur Jika Memilih "Ya" -->
            <script>
                document.addEventListener("DOMContentLoaded", function() {
                    let lemburYa = document.getElementById('lembur_ya');
                    let lemburTidak = document.getElementById('lembur_tidak');
                    let jamLemburSection = document.getElementById('jamLemburSection');
                    let jamLembur = document.getElementById('jam_lembur');

                    function toggleLembur() {
                        if (lemburYa.checked) {
                            jamLemburSection.style.display = 'block';
                            jamLembur.setAttribute('required', 'required');
                        } else {
                            jamLemburSection.style.display = 'none';
                            jamLembur.removeAttribute('required');
                            jamLembur.value = ''; // Reset nilai saat tidak lembur
                        }
                    }

                    lemburYa.addEventListener('change', toggleLembur);
                    lemburTidak.addEventListener('change', toggleLembur);
                });
            </script>
            <script src="vendor/jquery/jquery.min.js"></script>
            <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
            <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
            <script src="js/sb-admin-2.min.js"></script>
            <script src="vendor/datatables/jquery.dataTables.min.js"></script>
            <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
            <script>
                // Menampilkan/Menyembunyikan inputan terkait lembur
                $(document).ready(function() {
                    // Saat memilih Ya atau Tidak pada lembur
                    $('input[name="lembur"]').change(function() {
                        if ($('#lembur_ya').is(':checked')) {
                            $('#jamLemburSection').show(); // Menampilkan input jam lembur
                            $('#lamaLemburSection').show(); // Menampilkan input lama jam lembur
                        } else {
                            $('#jamLemburSection').hide(); // Menyembunyikan input jam lembur
                            $('#lamaLemburSection').hide(); // Menyembunyikan input lama jam lembur
                        }
                    });
                });
            </script>
            <script>
                $(document).ready(function() {
                    $('#dataTable').DataTable();
                });
            </script>

</body>

</html>