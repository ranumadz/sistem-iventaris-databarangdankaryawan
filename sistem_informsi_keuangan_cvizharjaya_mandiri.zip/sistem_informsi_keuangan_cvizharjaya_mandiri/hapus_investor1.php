<?php
require 'koneksi.php';

if (isset($_GET['id_investor'])) {
    $id_investor = $_GET['id_investor'];
    $query = "DELETE FROM investor WHERE id_investor = $id_investor";
    mysqli_query($koneksi, $query);
    header("Location: kelola-investor1.php");
    exit();
}
?>
