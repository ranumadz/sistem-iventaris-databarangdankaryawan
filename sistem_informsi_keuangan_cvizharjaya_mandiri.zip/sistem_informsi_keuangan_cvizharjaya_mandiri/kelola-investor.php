<?php
require 'cek-sesi.php';
require 'koneksi.php';
require 'sidebar.php';

// Fetch all investors
$query = mysqli_query($koneksi, "SELECT * FROM investor ORDER BY tanggal_investasi DESC");
$no = 1;
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Kelola Investor</title>
    <link rel="icon" href="img/cv_izhar_jaya_mandiri.jpeg" type="image/x-icon">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body id="page-top">

    <!-- Main Content -->
    <div id="content">
        <?php require 'navbar.php'; ?>
        <!-- Begin Page Content -->
        <div class="container-fluid">
            <!-- Page Heading -->
            <h1 class="h3 mb-2 text-gray-800">Daftar Investor</h1>
            <button type="button" class="btn btn-success" style="margin:5px" data-toggle="modal" data-target="#myModalTambah"><i class="fa fa-plus"> Tambah Investor</i></button><br>

            <!-- Investor Table -->
            <div class="card shadow mb-4">
                <div class="card-header py-3">
                    <h6 class="m-0 font-weight-bold text-primary">Daftar Investor</h6>
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>No. Urut</th>
                                    <th>Nama Investor</th>
                                    <th>Jumlah Investasi</th>
                                    <th>Tanggal Investasi</th>
                                    <th>Keterangan</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tfoot>
                                <tr>
                                    <th>No. Urut</th>
                                    <th>Nama Investor</th>
                                    <th>Jumlah Investasi</th>
                                    <th>Tanggal Investasi</th>
                                    <th>Keterangan</th>
                                    <th>Aksi</th>
                                </tr>
                            </tfoot>
                            <tbody>
                                <?php while ($data = mysqli_fetch_assoc($query)) { ?>
                                    <tr>
                                        <td><?= $no++ ?></td>
                                        <td><?= $data['nama_investor'] ?></td>
                                        <td><?= $data['jumlah_investasi'] ?></td>
                                        <td><?= $data['tanggal_investasi'] ?></td>
                                        <td><?= $data['keterangan'] ?></td>
                                        <td>
                                            <!-- Edit Button triggers modal -->
                                            <a href="#" class="fa fa-edit btn btn-primary btn-md" data-toggle="modal" data-target="#myModal<?= $data['id_investor']; ?>"></a>
                                            <!-- Delete Button triggers deletion -->
                                            <a href="hapus-investor.php?id_investor=<?= $data['id_investor']; ?>" onclick="return confirm('Anda Yakin Ingin Menghapus?')" class="fa fa-trash btn btn-danger btn-md"></a>
                                        </td>
                                    </tr>

                                    <!-- Modal Edit Investor -->
                                    <div class="modal fade" id="myModal<?= $data['id_investor']; ?>" role="dialog">
                                        <div class="modal-dialog">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h4 class="modal-title">Ubah Data Investor</h4>
                                                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                                                </div>
                                                <div class="modal-body">
                                                    <form action="proses-edit-investor.php" method="post">
                                                        <input type="hidden" name="id_investor" value="<?= $data['id_investor']; ?>">
                                                        <div class="form-group">
                                                            <label>Nama Investor</label>
                                                            <input type="text" name="nama_investor" class="form-control" value="<?= $data['nama_investor']; ?>" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Jumlah Investasi</label>
                                                            <input type="text" name="jumlah_investasi" class="form-control" value="<?= $data['jumlah_investasi']; ?>" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Tanggal Investasi</label>
                                                            <input type="date" name="tanggal_investasi" class="form-control" value="<?= $data['tanggal_investasi']; ?>" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label>Keterangan</label>
                                                            <textarea name="keterangan" class="form-control"><?= $data['keterangan']; ?></textarea>
                                                        </div>
                                                        <div class="modal-footer">
                                                            <button type="submit" class="btn btn-success">Ubah</button>
                                                            <button type="button" class="btn btn-default" data-dismiss="modal">Keluar</button>
                                                        </div>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.container-fluid -->
    </div>
    <!-- End of Main Content -->

    <!-- Modal Tambah Investor -->
    <div id="myModalTambah" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Tambah Investor</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;"></button>
                </div>
                <form action="tambah-investor.php" method="post">
                    <div class="modal-body">
                        <div class="form-group">
                            <label>Nama Investor</label>
                            <input type="text" class="form-control" name="nama_investor" required>
                        </div>
                        <div class="form-group">
                            <label>Jumlah Investasi</label>
                            <input type="text" class="form-control" name="jumlah_investasi" required>
                        </div>
                        <div class="form-group">
                            <label>Tanggal Investasi</label>
                            <input type="date" class="form-control" name="tanggal_investasi" required>
                        </div>
                        <div class="form-group">
                            <label>Keterangan</label>
                            <textarea class="form-control" name="keterangan"></textarea>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Tambah</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Keluar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <?php require 'footer.php'; ?>

    <!-- Scripts -->
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
</body>

</html>