<?php
require 'koneksi.php';

// Memeriksa apakah parameter id_penggajian dan status telah diterima
if (isset($_GET['id_gaji']) && isset($_GET['status'])) {
    $id_gaji = $_GET['id_gaji'];
    $status = $_GET['status'];

    // Menyiapkan dan menjalankan query untuk memperbarui status pembayaran di database
    $query = "UPDATE penggajian SET status_pembayaran = '$status' WHERE id_gaji = '$id_gaji'";
    $result = mysqli_query($koneksi, $query);

    if ($result) {
        // Jika query berhasil, tampilkan pesan sukses
        echo "<script>alert('Status pembayaran berhasil diubah!'); window.location='penggajian.php';</script>";
    } else {
        // Jika query gagal, tampilkan pesan error
        echo "<script>alert('Gagal mengubah status pembayaran, coba lagi!'); window.location='penggajian.php';</script>";
    }
} else {
    // Jika parameter tidak lengkap, tampilkan pesan error
    echo "<script>alert('Parameter tidak lengkap!'); window.location='penggajian.php';</script>";
}
