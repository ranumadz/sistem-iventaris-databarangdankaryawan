<?php
require 'koneksi.php';

if (isset($_GET['id_investor'])) {
    $id_investor = $_GET['id_investor'];
    $result = mysqli_query($koneksi, "SELECT * FROM investor WHERE id_investor = $id_investor");
    $row = mysqli_fetch_assoc($result);
}

// Proses update data
if (isset($_POST['update'])) {
    $nama_investor = $_POST['nama_investor'];
    $jumlah_investasi = $_POST['jumlah_investasi'];
    $tanggal_investasi = $_POST['tanggal_investasi'];
    $keterangan = $_POST['keterangan'];

    $query = "UPDATE investor SET nama_investor = '$nama_investor', jumlah_investasi = '$jumlah_investasi', 
              tanggal_investasi = '$tanggal_investasi', keterangan = '$keterangan' 
              WHERE id_investor = $id_investor";

    if (mysqli_query($koneksi, $query)) {
        header("Location: kelola-investor1.php");
        exit();
    } else {
        echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
    }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Investor</title>
    <link rel="stylesheet" href="path/to/bootstrap.min.css">
</head>

<body>

    <div class="container">
        <h1>Edit Investor</h1>

        <form method="post" action="">
            <div class="form-group">
                <label for="nama_investor">Nama Investor:</label>
                <input type="text" class="form-control" name="nama_investor" value="<?php echo $row['nama_investor']; ?>" required>
            </div>
            <div class="form-group">
                <label for="jumlah_investasi">Jumlah Investasi:</label>
                <input type="number" class="form-control" name="jumlah_investasi" value="<?php echo $row['jumlah_investasi']; ?>" required>
            </div>
            <div class="form-group">
                <label for="tanggal_investasi">Tanggal Investasi:</label>
                <input type="date" class="form-control" name="tanggal_investasi" value="<?php echo $row['tanggal_investasi']; ?>" required>
            </div>
            <div class="form-group">
                <label for="keterangan">Keterangan:</label>
                <textarea class="form-control" name="keterangan"><?php echo $row['keterangan']; ?></textarea>
            </div>
            <button type="submit" name="update" class="btn btn-primary">Update Investor</button>
        </form>
    </div>

    <script src="path/to/jquery.min.js"></script>
    <script src="path/to/bootstrap.bundle.min.js"></script>
</body>

</html>