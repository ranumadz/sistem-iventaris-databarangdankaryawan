<?php
include('koneksi.php');

$nama = $_GET['nama'];
$email = $_GET['email'];
$pass = $_GET['pass'];
$role = $_GET['role']; // Ambil role dari formulir

// Query untuk menambahkan admin baru dengan role
$query = mysqli_query($koneksi, "INSERT INTO `admin` (`nama`, `email`, `pass`, `role`) VALUES ('$nama', '$email', '$pass', '$role')");

if ($query) {
    // Redirect ke halaman profil
    header("location:profile.php");
} else {
    echo "ERROR, data gagal diupdate: " . mysqli_error($koneksi);
}
