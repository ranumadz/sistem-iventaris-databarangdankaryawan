<?php
// Generation of font definition file for tutorial 7
require('../makefont/makefont.php');

MakeFont('CevicheOne-Regular.ttf', 'cp1252');
?>
