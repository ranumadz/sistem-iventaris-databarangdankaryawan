<?php

require('fpdf/fpdf.php'); // Pastikan path sesuai dengan letak file fpdf.php

// Koneksi ke database
require('koneksi.php'); // Pastikan path sesuai dengan lokasi koneksi.php

// Cek koneksi
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

// Ambil filter bulan dan tahun dari parameter URL
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('m');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');

// Query pemasukan
$query_pemasukan = "SELECT id_pemasukan, tgl_pemasukan, jumlah, nama_sumber
FROM pemasukan
WHERE MONTH(tgl_pemasukan) = '$bulan' AND YEAR(tgl_pemasukan) = '$tahun'";
$result_pemasukan = mysqli_query($koneksi, $query_pemasukan);

// Query pengeluaran
$query_pengeluaran = "SELECT id_pengeluaran, tgl_pengeluaran, jumlah, nama_sumber
FROM pengeluaran
WHERE MONTH(tgl_pengeluaran) = '$bulan' AND YEAR(tgl_pengeluaran) = '$tahun'";
$result_pengeluaran = mysqli_query($koneksi, $query_pengeluaran);

// Inisialisasi PDF
$pdf = new FPDF();
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);

// Judul Laporan
$pdf->Cell(190, 10, 'Laporan Keuangan Bulanan CV Izhar Plastindo Persada', 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(190, 10, "Bulan: " . date('F Y', mktime(0, 0, 0, $bulan, 10, $tahun)), 0, 1, 'C');
$pdf->Ln(10);

// Bagian Pemasukan
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(190, 10, 'Pemasukan', 0, 1, 'L');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(40, 8, 'ID Pemasukan', 1);
$pdf->Cell(50, 8, 'Tanggal', 1);
$pdf->Cell(50, 8, 'Jumlah', 1);
$pdf->Cell(50, 8, 'Keterangan', 1);
$pdf->Ln();

$total_pemasukan = 0; // Inisialisasi total pemasukan

while ($row = mysqli_fetch_assoc($result_pemasukan)) {
    $pdf->Cell(40, 8, $row['id_pemasukan'], 1);
    $pdf->Cell(50, 8, $row['tgl_pemasukan'], 1);
    $pdf->Cell(50, 8, number_format($row['jumlah'], 0, ',', '.'), 1);
    $pdf->Cell(50, 8, $row['nama_sumber'], 1);
    $pdf->Ln();
    $total_pemasukan += $row['jumlah']; // Akumulasi jumlah pemasukan
}

// Tampilkan total pemasukan
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(140, 8, 'Total Pemasukan', 1);
$pdf->Cell(50, 8, number_format($total_pemasukan, 0, ',', '.'), 1, 1, 'R');

// Bagian Pengeluaran
$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(190, 10, 'Pengeluaran', 0, 1, 'L');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(40, 8, 'ID Pengeluaran', 1);
$pdf->Cell(50, 8, 'Tanggal', 1);
$pdf->Cell(50, 8, 'Jumlah', 1);
$pdf->Cell(50, 8, 'Keterangan', 1);
$pdf->Ln();

$total_pengeluaran = 0; // Inisialisasi total pengeluaran

while ($row = mysqli_fetch_assoc($result_pengeluaran)) {
    $pdf->Cell(40, 8, $row['id_pengeluaran'], 1);
    $pdf->Cell(50, 8, $row['tgl_pengeluaran'], 1);
    $pdf->Cell(50, 8, number_format($row['jumlah'], 0, ',', '.'), 1);
    $pdf->Cell(50, 8, $row['nama_sumber'], 1);
    $pdf->Ln();
    $total_pengeluaran += $row['jumlah']; // Akumulasi jumlah pengeluaran
}

// Tampilkan total pengeluaran
$pdf->SetFont('Arial', 'B', 12);
$pdf->Cell(140, 8, 'Total Pengeluaran', 1);
$pdf->Cell(50, 8, number_format($total_pengeluaran, 0, ',', '.'), 1, 1, 'R');

// Tampilkan saldo akhir
$saldo_akhir = $total_pemasukan - $total_pengeluaran;
$pdf->Ln(10);
$pdf->SetFont('Arial', 'B', 14);
$pdf->Cell(190, 10, 'Saldo Akhir', 0, 1, 'L');
$pdf->SetFont('Arial', '', 12);
$pdf->Cell(140, 8, 'Saldo Akhir Bulan Ini', 1);
$pdf->Cell(50, 8, number_format($saldo_akhir, 0, ',', '.'), 1, 1, 'R');

// Output PDF langsung ke browser
$pdf->Output('I', 'Laporan_Keuangan_' . $bulan . '_' . $tahun . '.pdf'); // 'I' untuk menampilkan di browser
