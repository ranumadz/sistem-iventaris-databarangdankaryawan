<?php
require 'cek-sesi.php'; // Untuk memeriksa sesi login
require 'koneksi.php';  // Koneksi ke database
require 'sidebar.php';  // Sidebar (menu navigasi)

// Default: Tampilkan data per bulan (menggunakan bulan dan tahun saat ini)
$bulan = isset($_POST['bulan']) ? $_POST['bulan'] : date('n'); // Mengambil bulan dari input atau bulan saat ini
$tahun = isset($_POST['tahun']) ? $_POST['tahun'] : date('Y'); // Mengambil tahun dari input atau tahun saat ini

$filter_tanggal = "MONTH(tgl_pemasukan) = '$bulan' AND YEAR(tgl_pemasukan) = '$tahun'"; // Filter untuk bulan dan tahun yang dipilih

// Jika filter bulan dan tahun dipilih
if (isset($_POST['filter_bulan'])) {
  $bulan = $_POST['bulan'];
  $tahun = $_POST['tahun'];
  $filter_tanggal = "MONTH(tgl_pemasukan) = '$bulan' AND YEAR(tgl_pemasukan) = '$tahun'"; // Filter untuk bulan dan tahun yang dipilih
}

// Proses input pendapatan
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['simpan_pendapatan'])) {
  // Ambil data dari form input
  $nama_sumber = $_POST['nama_sumber'];
  $tgl_pemasukan = $_POST['tgl_pemasukan'];
  $jumlah_pendapatan = $_POST['jumlah_pendapatan'];

  // Query untuk menyimpan data ke dalam tabel pemasukan
  $query = "INSERT INTO pemasukan (nama_sumber, tgl_pemasukan, jumlah) 
              VALUES ('$nama_sumber', '$tgl_pemasukan', '$jumlah_pendapatan')";

  $result = mysqli_query($koneksi, $query);

  // Periksa apakah query berhasil
  if ($result) {
    echo "<script>alert('Data berhasil disimpan!');</script>";
  } else {
    echo "<script>alert('Gagal menyimpan data: " . mysqli_error($koneksi) . "');</script>";
  }
}

// Proses update pendapatan
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['update_pendapatan'])) {
  $id_pemasukan = $_POST['id_pemasukan'];
  $nama_sumber = $_POST['nama_sumber'];
  $tgl_pemasukan = $_POST['tgl_pemasukan'];
  $jumlah_pendapatan = $_POST['jumlah_pendapatan'];

  $query = "UPDATE pemasukan SET nama_sumber = '$nama_sumber', tgl_pemasukan = '$tgl_pemasukan', jumlah = '$jumlah_pendapatan' WHERE id_pemasukan = '$id_pemasukan'";
  $result = mysqli_query($koneksi, $query);

  if ($result) {
    echo "<script>alert('Data berhasil diperbarui!');</script>";
  } else {
    echo "<script>alert('Gagal memperbarui data: " . mysqli_error($koneksi) . "');</script>";
  }
}

// Proses delete pendapatan
if (isset($_GET['delete_id'])) {
  $delete_id = $_GET['delete_id'];
  $query = "DELETE FROM pemasukan WHERE id_pemasukan = '$delete_id'";
  $result = mysqli_query($koneksi, $query);

  if ($result) {
    echo "<script>alert('Data berhasil dihapus!');</script>";
  } else {
    echo "<script>alert('Gagal menghapus data: " . mysqli_error($koneksi) . "');</script>";
  }
}
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Dashboard - Pendapatan</title>
  <link rel="icon" href="img/cv_izhar_jaya_mandiri.jpeg" type="image/x-icon">
  <!-- Custom fonts for this template-->
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
  <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
  <!-- Custom styles for this template-->
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
</head>

<body id="page-top">

  <!-- Main Content -->
  <div id="content">
    <?php require('navbar.php'); ?>

    <!-- Begin Page Content -->
    <div class="container-fluid">
      <!-- Filter Form -->
      <h2 class="h3 mb-2 text-gray-800 mt-4">Filter Data Pendapatan</h2>
      <form method="POST" action="pendapatan.php">
        <div class="row">
          <!-- Filter Bulan -->
          <div class="col-md-3">
            <div class="form-group">
              <label for="bulan">Bulan</label>
              <select class="form-control" name="bulan" id="bulan">
                <option value="">Pilih Bulan</option>
                <?php
                // Menampilkan opsi bulan
                for ($i = 1; $i <= 12; $i++) {
                  echo "<option value='$i'" . ($bulan == $i ? ' selected' : '') . ">" . date('F', mktime(0, 0, 0, $i, 10)) . "</option>";
                }
                ?>
              </select>
            </div>
          </div>
          <!-- Filter Tahun -->
          <div class="col-md-3">
            <div class="form-group">
              <label for="tahun">Tahun</label>
              <select class="form-control" name="tahun" id="tahun">
                <option value="">Pilih Tahun</option>
                <?php
                // Menampilkan opsi tahun dari tahun saat ini hingga 2030
                $current_year = date('Y');
                for ($i = $current_year; $i <= 2030; $i++) {
                  echo "<option value='$i'" . ($tahun == $i ? ' selected' : '') . ">$i</option>";
                }
                ?>
              </select>
            </div>
          </div>

        </div>
        <button type="submit" name="filter_bulan" class="btn btn-primary">Filter</button>
      </form>

      <!-- Tombol untuk Menampilkan Modal Input Pendapatan -->
      <button id="showInputModalBtn" class="btn btn-success mt-4" data-toggle="modal" data-target="#inputModal">Input Pendapatan</button>

      <!-- Modal Input Pendapatan -->
      <div class="modal fade" id="inputModal" tabindex="-1" role="dialog" aria-labelledby="inputModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
          <div class="modal-content">
            <div class="modal-header">
              <h5 class="modal-title" id="inputModalLabel">Input Data Pendapatan</h5>
              <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                <span aria-hidden="true">&times;</span>
              </button>
            </div>
            <div class="modal-body">
              <form action="pendapatan.php" method="POST">
                <div class="form-group">
                  <label for="nama_sumber">Sumber Pemasukan</label>
                  <input type="text" class="form-control" id="nama_sumber" name="nama_sumber" required>
                </div>
                <div class="form-group">
                  <label for="tgl_pemasukan">Tanggal Pemasukan</label>
                  <input type="date" class="form-control" id="tgl_pemasukan" name="tgl_pemasukan" required>
                </div>
                <div class="form-group">
                  <label for="jumlah_pendapatan">Jumlah Pemasukan</label>
                  <input type="number" class="form-control" id="jumlah_pendapatan" name="jumlah_pendapatan" required>
                </div>
                <button type="submit" name="simpan_pendapatan" class="btn btn-primary">Simpan</button>
              </form>
            </div>
          </div>
        </div>
      </div>

      <!-- Table Data Pendapatan -->
      <h2 class="h3 mb-2 text-gray-800 mt-4">Data Pendapatan</h2>
      <table class="table table-bordered">
        <thead>
          <tr>
            <th>Sumber Pemasukan</th>
            <th>Tanggal Pemasukan</th>
            <th>Jumlah Pemasukan</th>
            <th>Aksi</th>
          </tr>
        </thead>
        <tbody>
          <?php
          // Query untuk mengambil data berdasarkan filter
          $query = "SELECT * FROM pemasukan WHERE $filter_tanggal ORDER BY tgl_pemasukan DESC";
          $result = mysqli_query($koneksi, $query);

          if ($result) {
            while ($data = mysqli_fetch_array($result)) {
              echo '
                <tr>
                  <td>' . htmlspecialchars($data['nama_sumber']) . '</td>
                  <td>' . htmlspecialchars($data['tgl_pemasukan']) . '</td>
                  <td>Rp ' . number_format($data['jumlah'], 2, ',', '.') . '</td>
                  <td>
                    <button class="btn btn-warning" data-toggle="modal" data-target="#editModal' . $data['id_pemasukan'] . '">Edit</button>
                    <a href="pendapatan.php?delete_id=' . $data['id_pemasukan'] . '" class="btn btn-danger">Delete</a>
                  </td>
                </tr>';
            }
          } else {
            echo "<tr><td colspan='4'>Tidak ada data yang sesuai dengan filter.</td></tr>";
          }
          ?>
        </tbody>
      </table>
    </div>
  </div>

  <!-- Footer -->
  <?php require 'footer.php'; ?>

  <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="js/sb-admin-2.min.js"></script>

</body>