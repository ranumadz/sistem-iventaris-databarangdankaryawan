<?php
require 'koneksi.php'; // Koneksi ke database
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Admin Karyawan</title>
    <link rel="stylesheet" href="css/sb-admin-2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <style>
        body {
            background: url('img/background.jpg') no-repeat center center fixed;
            background-size: cover;
            color: white;
            margin: 0;
            padding: 0;
            width: 100vw;
            overflow-x: hidden;
            /* Biar nggak ada scroll horizontal */
        }

        #wrapper {
            display: flex;
            width: 100%;
            min-height: 100vh;
        }

        #content-wrapper {
            flex-grow: 1;
            width: 100%;
        }

        .container-fluid {
            max-width: 100%;
            padding: 40px;
            text-align: center;
        }

        /* Meningkatkan keterbacaan teks */
        .dashboard-title {
            color: #888;
            /* Ubah menjadi abu-abu */
            /* Atau untuk warna lain, seperti hitam */
            color: #333;
            /* Ubah menjadi warna yang lebih gelap */
        }

        .lead {
            color: #aaa;
            /* Ubah menjadi abu-abu lebih terang */
            /* Atau untuk warna hitam */
            color: #666;
            /* Ubah menjadi lebih gelap */
        }


        .card-custom {
            background: rgba(255, 255, 255, 0.15);
            border: none;
            border-radius: 15px;
            padding: 30px;
            transition: 0.3s;
            color: white;
            text-shadow: 1px 1px 3px rgba(0, 0, 0, 0.7);
            /* Biar teks tetap kelihatan */
        }

        .p {
            color: rgb(21, 22, 22);
        }

        .card-custom:hover {
            background: rgba(255, 255, 255, 0.3);
            transform: scale(1.05);
            box-shadow: 0px 5px 20px rgba(255, 255, 255, 0.3);
        }

        /* Ukuran ikon lebih besar biar lebih menonjol */
        .icon-custom {
            font-size: 70px;
            margin-bottom: 15px;
            color: white;
            text-shadow: 2px 2px 5px rgba(0, 0, 0, 0.7);
        }

        /* Blur box yang lebih gelap biar teks lebih jelas */
        .blur-box {
            background: rgba(0, 0, 0, 0.6);
            /* Dibuat lebih gelap */
            border-radius: 15px;
            padding: 20px;
            backdrop-filter: blur(10px);
            text-align: center;
            max-width: 600px;
            margin: auto;
        }

        .blur-box h5,
        .blur-box p {
            color: #888;
            /* Untuk abu-abu */
            /* Atau untuk hitam */
            color: #000000;
            /* Untuk hitam */
        }
    </style>
</head>

<body>
    <div id="wrapper">
        <!-- Sidebar -->
        <?php require 'sidebar2.php'; ?>

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <div class="container-fluid">
                    <h1 class="dashboard-title">Selamat Datang, Admin</h1>
                    <p class="lead">Kelola dan pantau semua aktivitas karyawan dengan mudah</p>

                    <div class="row justify-content-center">
                        <!-- Absensi Karyawan -->
                        <div class="col-lg-4 col-md-6 mb-4">
                            <a href="absensi_karyawan2.php" class="text-decoration-none">
                                <div class="card card-custom shadow text-center">
                                    <i class="fas fa-calendar-check icon-custom"></i>
                                    <h4 class="font-weight-bold">Absensi Karyawan</h4>
                                </div>
                            </a>
                        </div>

                        <!-- Data Karyawan -->
                        <div class="col-lg-4 col-md-6 mb-4">
                            <a href="karyawan2.php" class="text-decoration-none">
                                <div class="card card-custom shadow text-center">
                                    <i class="fas fa-users icon-custom"></i>
                                    <h4 class="font-weight-bold">Data Karyawan</h4>
                                </div>
                            </a>
                        </div>

                        <!-- Penggajian -->
                        <div class="col-lg-4 col-md-6 mb-4">
                            <a href="penggajian2.php" class="text-decoration-none">
                                <div class="card card-custom shadow text-center">
                                    <i class="fas fa-money-check-alt icon-custom"></i>
                                    <h4 class="font-weight-bold">Penggajian</h4>
                                </div>
                            </a>
                        </div>
                    </div>

                    <!-- Info Tambahan -->
                    <div class="row justify-content-center">
                        <div class="col-lg-6">
                            <div class="blur-box mt-4">
                                <h5 class="text-white">Tips Admin</h5>
                                <p>Pastikan data karyawan selalu diperbarui dan absensi diperiksa secara berkala.</p>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>

</body>

</html>