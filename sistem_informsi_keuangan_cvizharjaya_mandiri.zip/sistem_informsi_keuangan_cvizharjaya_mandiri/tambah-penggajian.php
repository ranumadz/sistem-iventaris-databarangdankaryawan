<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id_karyawan = $_POST['id_karyawan'];
    $jumlah_gaji = $_POST['jumlah_gaji'];
    $tanggal_pembayaran = $_POST['tanggal_pembayaran']; // Tambahkan input tanggal pembayaran
    $jumlah_hari_kerja = $_POST['jumlah_hari_kerja']; // Tambahkan input hari kerja
    $jumlah_lembur = $_POST['jumlah_lembur']; // Tambahkan input lembur

    // Pastikan semua data diisi
    if (empty($id_karyawan) || empty($jumlah_gaji) || empty($tanggal_pembayaran) || empty($jumlah_hari_kerja) || empty($jumlah_lembur)) {
        echo "<script>alert('Harap isi semua field!'); window.location='penggajian.php';</script>";
        exit;
    }

    // Insert data ke tabel penggajian tanpa bulan dan tahun
    $query = "INSERT INTO penggajian (id_karyawan, jumlah_gaji, tanggal_pembayaran, jumlah_hari_kerja, jumlah_lembur, status_pembayaran) 
              VALUES ('$id_karyawan', '$jumlah_gaji', '$tanggal_pembayaran', '$jumlah_hari_kerja', '$jumlah_lembur', 'belum')";

    $result = mysqli_query($koneksi, $query);

    if ($result) {
        echo "<script>alert('Penggajian berhasil ditambahkan!'); window.location='penggajian.php';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan, coba lagi!'); window.location='penggajian.php';</script>";
    }
}
