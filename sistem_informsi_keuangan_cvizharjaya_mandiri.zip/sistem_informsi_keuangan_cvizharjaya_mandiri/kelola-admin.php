<?php
require 'koneksi.php'; // Pastikan file koneksi.php sudah ada dan berfungsi

// Ambil data admin dari database
$query = "SELECT * FROM admin";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Kelola Admin</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <script src="https://unpkg.com/sweetalert/dist/sweetalert.min.js"></script>
</head>

<body>

    <div class="container mt-5">
        <h2>Kelola Admin</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID Admin</th>
                    <th>Nama</th>
                    <th>Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php while ($data = mysqli_fetch_assoc($result)): ?>
                    <tr>
                        <td><?= $data['id_admin'] ?></td>
                        <td><?= $data['nama'] ?></td>
                        <td>
                            <form action="proses-hapus-admin.php" method="post" style="display:inline;">
                                <input type="hidden" name="id_admin" value="<?= $data['id_admin'] ?>">
                                <button type="button" class="fa fa-trash btn btn-danger btn-md"
                                    onclick="confirmDelete('<?= $data['nama'] ?>', this.form);"></button>
                            </form>
                            <a href="#" class="fa fa-edit btn btn-primary btn-md" data-toggle="modal" data-target="#myModal<?= $data['id_admin']; ?>">Edit</a>
                        </td>
                    </tr>
                <?php endwhile; ?>
            </tbody>
        </table>
    </div>

    <script>
        function confirmDelete(adminName, form) {
            swal({
                    title: "Anda yakin?",
                    text: "Anda akan menghapus admin " + adminName + "!",
                    icon: "warning",
                    buttons: true,
                    dangerMode: true,
                })
                .then((willDelete) => {
                    if (willDelete) {
                        form.submit(); // Jika pengguna mengkonfirmasi, kirimkan form
                    } else {
                        swal("Penghapusan dibatalkan!");
                    }
                });
        }
    </script>

</body>

</html>