<?php
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dari form
    $id_gaji = $_POST['id_gaji'];
    $id_karyawan = $_POST['id_karyawan'];
    $jumlah_gaji = $_POST['jumlah_gaji'];
    $tanggal_pembayaran = $_POST['tanggal_pembayaran'];
    $jumlah_hari_kerja = $_POST['jumlah_hari_kerja'];
    $jumlah_lembur = $_POST['jumlah_lembur'];

    // Validasi form, pastikan tidak ada yang kosong
    if (empty($id_karyawan) || empty($jumlah_gaji) || empty($tanggal_pembayaran) || empty($jumlah_hari_kerja) || empty($jumlah_lembur)) {
        echo "<script>alert('Harap isi semua field!'); window.location='edit-penggajian.php?id_gaji=$id_gaji';</script>";
        exit;
    }

    // Query untuk memperbarui data penggajian
    $query = "UPDATE penggajian SET 
              id_karyawan='$id_karyawan', 
              jumlah_gaji='$jumlah_gaji', 
              tanggal_pembayaran='$tanggal_pembayaran', 
              jumlah_hari_kerja='$jumlah_hari_kerja', 
              jumlah_lembur='$jumlah_lembur' 
              WHERE id_gaji='$id_gaji'";

    $result = mysqli_query($koneksi, $query);

    if ($result) {
        echo "<script>alert('Penggajian berhasil diperbarui!'); window.location='penggajian.php';</script>";
    } else {
        echo "<script>alert('Terjadi kesalahan, coba lagi!'); window.location='edit-penggajian.php?id_gaji=$id_gaji';</script>";
    }
}
