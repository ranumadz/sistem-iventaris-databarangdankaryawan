<?php
require 'cek-sesi.php'; // Pastikan sesi valid
require 'koneksi.php'; // Koneksi ke database
require 'sidebar.php'; // Menyertakan sidebar jika ada

// Ambil data barang masuk dengan filter
$filterTanggal = isset($_GET['tanggal_filter']) ? mysqli_real_escape_string($koneksi, $_GET['tanggal_filter']) : date('Y-m-d'); // Default ke hari ini

// Membuat kondisi query berdasarkan filter
$whereClauses = [];
if ($filterTanggal) {
    $whereClauses[] = "DATE(tanggal_masuk) = '$filterTanggal'"; // Filter berdasarkan tanggal
}

// Gabungkan kondisi filter jika ada
$whereQuery = count($whereClauses) > 0 ? "WHERE " . implode(" AND ", $whereClauses) : "";

// Query untuk mengambil data barang masuk
$query = "SELECT * FROM barang_masuk $whereQuery";
$result = mysqli_query($koneksi, $query);

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Barang Masuk</title>
    <link rel="icon" href="img/cv_izhar_jaya_mandiri.jpeg" type="image/x-icon">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
</head>

<body id="page-top">

    <div id="content">
        <?php require 'navbar.php'; ?>
        <div class="container-fluid">
            <!-- Filter Form -->
            <h2 class="h3 mb-2 text-gray-800 mt-4">Filter Data Barang</h2>
            <form method="GET" action="barang_masuk.php">
                <div class="row">
                    <!-- Filter Tanggal -->
                    <div class="col-md-4">
                        <div class="form-group">
                            <label for="tanggal_filter">Tanggal Masuk</label>
                            <input type="date" class="form-control" id="tanggal_filter" name="tanggal_filter" value="<?= htmlspecialchars($filterTanggal) ?>">
                        </div>
                    </div>
                </div>
                <button type="submit" class="btn btn-primary">Filter</button>
            </form>

            <!-- Tombol untuk Menampilkan Modal Input Barang -->
            <button id="showInputModalBtn" class="btn btn-success mt-4" data-toggle="modal" data-target="#inputModalBerat">Input Barang Berat</button>

            <!-- Modal Input Barang Berat (kg, ons) -->
            <div class="modal fade" id="inputModalBerat" tabindex="-1" role="dialog" aria-labelledby="inputModalBeratLabel" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="inputModalBeratLabel">Barang Masuk</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <<form action="proses_barang_masuk.php" method="POST">
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="kode_barang">Nama Suplier</label>
                                            <input type="text" class="form-control" id="kode_barang" name="kode_barang" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="nama_barang">Nama Barang</label>
                                            <input type="text" class="form-control" id="nama_barang" name="nama_barang" required>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="quantity_masuk">Jumlah Barang</label>
                                            <input type="text" class="form-control" id="quantity_masuk" name="quantity_masuk" placeholder="Contoh: 2.3" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="satuan">Satuan</label>
                                            <select class="form-control" id="satuan" name="satuan" required>
                                                <option value="kg">Kilogram (kg)</option>
                                                <option value="ons">Ons (ons)</option>
                                                <option value="pcs">Pcs (pcs)</option>
                                            </select>
                                        </div>
                                    </div>
                                </div>

                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="harga_per_kg">Harga</label>
                                            <input type="text" class="form-control" id="harga_per_kg" name="harga_per_kg" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="total_harga">Total Harga</label>
                                            <input type="text" class="form-control" id="total_harga" name="total_harga" placeholder="Masukkan total harga manual" required>
                                        </div>
                                    </div>
                                </div>

                                <!-- Row untuk Tanggal Masuk dan Keterangan agar sejajar -->
                                <div class="row">
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="tanggal_masuk">Tanggal Masuk</label>
                                            <input type="date" class="form-control" id="tanggal_masuk" name="tanggal_masuk" required>
                                        </div>
                                    </div>
                                    <div class="col-md-6">
                                        <div class="form-group">
                                            <label for="keterangan">Keterangan</label>
                                            <input type="text" class="form-control" id="keterangan" name="keterangan">
                                        </div>
                                    </div>
                                </div>
                                <!-- Akhir Row untuk Tanggal Masuk dan Keterangan -->

                                <button type="submit" class="btn btn-primary">Simpan</button>
                                </form>

                        </div>
                    </div>
                </div>
            </div>

            <!-- Table Data Barang -->
            <h2 class="h3 mb-2 text-gray-800 mt-4">Data Barang Masuk</h2>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nama Suplier</th>
                        <th>Nama Barang</th>
                        <th>Jumlah Barang</th>
                        <th>Satuan</th>
                        <th>Harga </th>
                        <th>Total Harga</th> <!-- Tambahkan Total Harga di Header -->
                        <th>Tanggal Masuk</th>
                        <th>Keterangan Barang</th>
                        <th>Aksi/Pengaturan</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) { ?>
                            <tr>
                                <td><?= htmlspecialchars($row['kode_barang']) ?></td>
                                <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                                <td><?= htmlspecialchars($row['quantity_masuk']) ?></td>
                                <td><?= htmlspecialchars($row['satuan']) ?></td>
                                <td>Rp <?= number_format($row['harga_per_kg'], 0, ',', '.') ?></td>
                                <td>Rp <?= number_format($row['total_harga'], 0, ',', '.') ?></td> <!-- Tambahkan Total Harga di Data -->
                                <td><?= htmlspecialchars($row['tanggal_masuk']) ?></td>
                                <td><?= htmlspecialchars($row['keterangan']) ?></td>
                                <td>
                                    <button class="btn btn-warning" data-toggle="modal" data-target="#editModal<?= $row['id'] ?>">Edit</button>
                                    <button class="btn btn-danger" onclick="hapusBarang(<?= $row['id'] ?>)">Hapus</button>
                                </td>
                            </tr>
                        <?php }
                    } else { ?>
                        <tr>
                            <td colspan="9" class="text-center">Tidak ada data barang masuk</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php
    // Loop untuk membuat modal edit untuk setiap barang masuk
    $result = mysqli_query($koneksi, $query);
    while ($row = mysqli_fetch_assoc($result)) {
    ?>
        <div class="modal fade" id="editModal<?= $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel<?= $row['id'] ?>" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="editModalLabel<?= $row['id'] ?>">Barang Masuk</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form action="proses_barang_masuk.php" method="POST">
                            <input type="hidden" name="id" value="<?= $row['id'] ?>">

                            <div class="form-group">
                                <label for="edit_kode_barang">Nama Suplier</label>
                                <input type="text" class="form-control" id="edit_kode_barang" name="kode_barang" value="<?= htmlspecialchars($row['kode_barang']) ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="edit_nama_barang">Nama Barang</label>
                                <input type="text" class="form-control" id="edit_nama_barang" name="nama_barang" value="<?= htmlspecialchars($row['nama_barang']) ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="edit_quantity_masuk">Jumlah Barang</label>
                                <input type="text" class="form-control" id="edit_quantity_masuk" name="quantity_masuk" value="<?= htmlspecialchars($row['quantity_masuk']) ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="edit_satuan">Satuan</label>
                                <select class="form-control" id="edit_satuan" name="satuan" required>
                                    <option value="kg" <?= ($row['satuan'] == 'kg') ? 'selected' : '' ?>>Kilogram (kg)</option>
                                    <option value="ons" <?= ($row['satuan'] == 'ons') ? 'selected' : '' ?>>Ons (ons)</option>
                                    <option value="pcs" <?= ($row['satuan'] == 'pcs') ? 'selected' : '' ?>>Pcs (pcs)</option>
                                </select>
                            </div>

                            <div class="form-group">
                                <label for="edit_harga_per_kg">Harga </label>
                                <input type="text" class="form-control" id="edit_harga_per_kg" name="harga_per_kg" value="<?= htmlspecialchars($row['harga_per_kg']) ?>" required>
                            </div>
                            <div class="form-group">
                                <label for="edit_total_harga">Total Harga</label>
                                <input type="text" class="form-control" id="edit_total_harga" name="total_harga" value="<?= htmlspecialchars($row['total_harga']) ?>" required>
                            </div>

                            <div class="form-group">
                                <label for="edit_keterangan">Keterangan</label>
                                <input type="text" class="form-control" id="edit_keterangan" name="keterangan" value="<?= htmlspecialchars($row['keterangan']) ?>">
                            </div>

                            <button type="submit" class="btn btn-primary" name="edit_barang">Simpan Perubahan</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    <?php } ?>

    <script>
        function hapusBarang(id) {
            if (confirm('Apakah Anda yakin ingin menghapus barang ini?')) {
                window.location.href = 'proses_barang_masuk.php?action=delete&id=' + id;
            }
        }
    </script>
    <!-- jQuery dan Popper.js (Harus ada sebelum Bootstrap JS) -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.7/umd/popper.min.js"></script>

    <!-- Bootstrap JS -->
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
    <script>
        // Mengganti titik dengan koma di input jumlah berat saat submit
        document.querySelector('form').addEventListener('submit', function(event) {
            let quantityInput = document.getElementById('quantity_masuk');
            if (quantityInput) {
                quantityInput.value = quantityInput.value.replace('.', ','); // Mengganti titik dengan koma
            }
        });
    </script>

</body>

</html>