<?php
require 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_karyawan = $_POST['id_karyawan'] ?? null;
    $jam_keluar = $_POST['jam_keluar'] ?? null;

    if (empty($id_karyawan) || empty($jam_keluar)) {
        header("Location: absensi_karyawan.php?error=ID Karyawan dan Jam Keluar wajib diisi");
        exit;
    }

    // Cek apakah karyawan sudah melakukan absen masuk
    $query = "SELECT id_absen, absen_masuk FROM absensi_karyawan 
              WHERE id_karyawan = ? AND absen_keluar IS NULL 
              ORDER BY tanggal_masuk DESC LIMIT 1";
    $stmt = $koneksi->prepare($query);
    if (!$stmt) {
        error_log("Query prepare failed: " . $koneksi->error);
        header("Location: absensi_karyawan.php?error=Terjadi kesalahan sistem");
        exit;
    }

    $stmt->bind_param('s', $id_karyawan);
    $stmt->execute();
    $stmt->store_result();

    if ($stmt->num_rows > 0) {
        $stmt->bind_result($id_absen, $absen_masuk);
        $stmt->fetch();

        if ($jam_keluar < $absen_masuk) {
            header("Location: absensi_karyawan.php?error=Jam keluar tidak boleh lebih awal dari jam masuk");
            exit;
        }

        $query_update = "UPDATE absensi_karyawan SET absen_keluar = ? WHERE id_absen = ?";
        $stmt_update = $koneksi->prepare($query_update);
        if (!$stmt_update) {
            error_log("Query prepare update failed: " . $koneksi->error);
            header("Location: absensi_karyawan.php?error=Terjadi kesalahan sistem");
            exit;
        }

        $stmt_update->bind_param('ss', $jam_keluar, $id_absen);
        if ($stmt_update->execute()) {
            header("Location: absensi_karyawan.php?success=Absensi keluar berhasil ditambahkan");
        } else {
            header("Location: absensi_karyawan.php?error=Gagal memperbarui absensi keluar");
        }
        $stmt_update->close();
    } else {
        header("Location: absensi_karyawan.php?error=Absensi masuk tidak ditemukan untuk karyawan ini");
    }

    $stmt->close();
}
