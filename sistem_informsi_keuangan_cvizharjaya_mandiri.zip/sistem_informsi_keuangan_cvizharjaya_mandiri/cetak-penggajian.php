<?php
require 'koneksi.php';
require 'fpdf/fpdf.php';

// Ambil tanggal filter dari GET request
$tanggal_filter = isset($_GET['tanggal_filter']) ? $_GET['tanggal_filter'] : '';

// Buat instance FPDF
$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetMargins(10, 10, 10); // Tambahkan margin biar tabel tidak kepotong
$pdf->SetFont('Arial', 'B', 14);

// Tambahkan Logo
$pdf->Image('img/logo_cv.jpeg', 160, 10, 25); // Kurangi ukuran logo biar pas

// Header
$pdf->Cell(0, 10, 'Laporan Penggajian Karyawan', 0, 1, 'C');
$pdf->SetFont('Arial', '', 12);
$pdf->Ln(10);

// Table Header (Dikecilkan)
$pdf->SetFont('Arial', 'B', 9);
$pdf->Cell(20, 7, 'ID', 1);
$pdf->Cell(40, 7, 'Nama', 1);
$pdf->Cell(20, 7, 'Hari Kerja', 1);
$pdf->Cell(20, 7, 'Lembur', 1);
$pdf->Cell(30, 7, 'Gaji (Rp)', 1);
$pdf->Cell(30, 7, 'Tanggal Bayar', 1);
$pdf->Cell(20, 7, 'Status', 1);
$pdf->Ln();

// Query untuk menampilkan data berdasarkan filter tanggal
$query = "SELECT penggajian.id_karyawan, karyawan.nama, penggajian.jumlah_hari_kerja, 
                 penggajian.jumlah_lembur, penggajian.jumlah_gaji, penggajian.tanggal_pembayaran, 
                 penggajian.status_pembayaran 
          FROM penggajian 
          JOIN karyawan ON penggajian.id_karyawan = karyawan.id_karyawan";

if (!empty($tanggal_filter)) {
    $query .= " WHERE penggajian.tanggal_pembayaran = '$tanggal_filter'";
}

$result = mysqli_query($koneksi, $query);
$pdf->SetFont('Arial', '', 9);

// Menampilkan data (Lebar tabel lebih kecil)
while ($data = mysqli_fetch_assoc($result)) {
    $pdf->Cell(20, 7, $data['id_karyawan'], 1);
    $pdf->Cell(40, 7, $data['nama'], 1);
    $pdf->Cell(20, 7, $data['jumlah_hari_kerja'], 1);
    $pdf->Cell(20, 7, $data['jumlah_lembur'], 1);
    $pdf->Cell(30, 7, number_format($data['jumlah_gaji'], 2, ',', '.'), 1);
    $pdf->Cell(30, 7, $data['tanggal_pembayaran'], 1);
    $pdf->Cell(20, 7, $data['status_pembayaran'], 1);
    $pdf->Ln();
}

// Output PDF
$pdf->Output('D', 'Laporan_Penggajian.pdf');
