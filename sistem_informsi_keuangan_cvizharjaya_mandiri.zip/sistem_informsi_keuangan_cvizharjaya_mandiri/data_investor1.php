<?php
require 'koneksi.php';

// Mendapatkan data investor untuk ditampilkan
$result = mysqli_query($koneksi, "SELECT * FROM investor");
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Investor</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
    <style>
        .bg-gradient-primary {
            background-color: #4e73df;
            background-image: linear-gradient(180deg, #4e73df 10%, #224abe 100%);
            color: white;
        }
    </style>
</head>

<body>
    <div id="wrapper">
        <!-- Sidebar -->
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <!-- Nav Item - Investor Collapse Menu -->
            <li class="nav-item">
                <a class="nav-link collapsed" href="javascript:void(0)" data-toggle="collapse" data-target="#collapseInvestor" aria-expanded="false" aria-controls="collapseInvestor">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Investor</span>
                </a>
                <div id="collapseInvestor" class="collapse" aria-labelledby="headingInvestor" data-parent="#accordionSidebar">
                    <div class="bg-white py-2 collapse-inner rounded">
                        <h6 class="collapse-header">Investor Menu:</h6>
                        <a class="collapse-item" href="kelola-investor1.php">Kelola Investor</a>
                        <a class="collapse-item" href="data_investor1.php">Data Investor</a>
                    </div>
                </div>
            </li>
            <!-- Kembali ke Dashboard -->
            <li class="nav-item">
                <a class="nav-link" href="admin_limbah_dashboard.php">
                    <i class="fas fa-fw fa-tachometer-alt"></i>
                    <span>Kembali ke Dashboard</span>
                </a>
            </li>
            <!-- Tambahkan menu lain sesuai kebutuhan -->
        </ul>

        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <div class="container-fluid">
                    <h1>Data Investor</h1>
                    <table class="table">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nama Investor</th>
                                <th>Jumlah Investasi</th>
                                <th>Tanggal Investasi</th>
                                <th>Keterangan</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php while ($row = mysqli_fetch_assoc($result)): ?>
                                <tr>
                                    <td><?php echo $row['id_investor']; ?></td>
                                    <td><?php echo $row['nama_investor']; ?></td>
                                    <td><?php echo $row['jumlah_investasi']; ?></td>
                                    <td><?php echo $row['tanggal_investasi']; ?></td>
                                    <td><?php echo $row['keterangan']; ?></td>
                                </tr>
                            <?php endwhile; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap/5.3.0/js/bootstrap.bundle.min.js"></script>
</body>

</html>