<!-- Footer -->
<footer class="sticky-footer bg-white">
  <div class="container my-auto">
    <div class="copyright text-center my-auto">
      <span>
        Copyright &copy; | @scriptify -
        <a href="https://wa.me/628978812256" target="_blank" style="text-decoration: none; color: #25d366; font-weight: bold;">
          08978812256
        </a>
        <br>
        <small>Jasa Pembuatan Aplikasi Web & Mobile | Hubungi Kami di WhatsApp!</small>
      </span>
    </div>
  </div>
</footer>
<!-- End of Footer -->