<?php
// Koneksi ke database
include 'koneksi.php';  // Pastikan ini benar-benar memasukkan koneksi.php

// Default filter bulan dan tahun
$bulan = isset($_GET['bulan']) ? $_GET['bulan'] : date('m');
$tahun = isset($_GET['tahun']) ? $_GET['tahun'] : date('Y');
?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Laporan Keuangan</title>
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f8f9fa;
      padding: 20px;
    }

    .container {
      max-width: 900px;
      margin: auto;
      background: white;
      padding: 20px;
      border-radius: 8px;
      box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
      text-align: center;
      margin-bottom: 20px;
    }

    .table {
      margin-top: 20px;
    }

    .table th {
      background-color: #f4f4f4;
    }

    .d-flex {
      display: flex;
      justify-content: space-between;
    }
  </style>
</head>

<body>
  <div class="container">
    <h1>Laporan Keuangan</h1>

    <!-- Form Filter Bulan dan Tahun -->
    <form class="row g-3 mb-4" method="GET">
      <div class="col-md-4">
        <label for="bulan" class="form-label">Pilih Bulan:</label>
        <select name="bulan" id="bulan" class="form-select" required>
          <?php
          for ($i = 1; $i <= 12; $i++) {
            $selected = ($i == $bulan) ? 'selected' : '';
            echo "<option value='$i' $selected>" . date('F', mktime(0, 0, 0, $i, 10)) . "</option>";
          }
          ?>
        </select>
      </div>
      <div class="col-md-4">
        <label for="tahun" class="form-label">Pilih Tahun:</label>
        <select name="tahun" id="tahun" class="form-select" required>
          <?php
          $currentYear = date('Y');
          $maxYear = $currentYear + 5; // Menambahkan opsi hingga 5 tahun ke depan
          for ($i = $currentYear - 5; $i <= $maxYear; $i++) {
            $selected = ($i == $tahun) ? 'selected' : '';
            echo "<option value='$i' $selected>$i</option>";
          }
          ?>

        </select>
      </div>
      <div class="col-md-4 d-flex align-items-end">
        <button type="submit" class="btn btn-primary w-100">Tampilkan Data</button>
      </div>
    </form>

    <!-- Tabel Pemasukan -->
    <h2 class="mt-4">Data Pemasukan</h2>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>ID Pemasukan</th>
          <th>Tanggal</th>
          <th>Jumlah</th>
          <th>Keterangan</th>
        </tr>
      </thead>
      <tbody>
        <?php
        // Query data pemasukan
        $query_pemasukan = "SELECT id_pemasukan, tgl_pemasukan, jumlah, nama_sumber AS keterangan 
                            FROM pemasukan 
                            WHERE MONTH(tgl_pemasukan) = '$bulan' AND YEAR(tgl_pemasukan) = '$tahun'";
        $result_pemasukan = mysqli_query($koneksi, $query_pemasukan);

        $total_pemasukan = 0;

        if (mysqli_num_rows($result_pemasukan) > 0) {
          while ($row = mysqli_fetch_assoc($result_pemasukan)) {
            $total_pemasukan += $row['jumlah'];
            echo "<tr>
                    <td>{$row['id_pemasukan']}</td>
                    <td>{$row['tgl_pemasukan']}</td>
                    <td>" . number_format($row['jumlah'], 0, ',', '.') . "</td>
                    <td>{$row['keterangan']}</td>
                  </tr>";
          }
          echo "<tr>
                  <td colspan='2' class='text-end'><strong>Total Pemasukan</strong></td>
                  <td colspan='2'><strong>" . number_format($total_pemasukan, 0, ',', '.') . "</strong></td>
                </tr>";
        } else {
          echo "<tr><td colspan='4' class='text-center'>Tidak ada data pemasukan untuk bulan ini.</td></tr>";
        }
        ?>
      </tbody>
    </table>

    <!-- Tabel Pengeluaran -->
    <h2 class="mt-4">Data Pengeluaran</h2>
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>ID Pengeluaran</th>
          <th>Tanggal</th>
          <th>Jumlah</th>
          <th>Keterangan</th>
        </tr>
      </thead>
      <tbody>
        <?php
        // Query data pengeluaran
        $query_pengeluaran = "SELECT id_pengeluaran, tgl_pengeluaran, jumlah, nama_sumber AS keterangan 
                              FROM pengeluaran 
                              WHERE MONTH(tgl_pengeluaran) = '$bulan' AND YEAR(tgl_pengeluaran) = '$tahun'";
        $result_pengeluaran = mysqli_query($koneksi, $query_pengeluaran);

        $total_pengeluaran = 0;

        if (mysqli_num_rows($result_pengeluaran) > 0) {
          while ($row = mysqli_fetch_assoc($result_pengeluaran)) {
            $total_pengeluaran += $row['jumlah'];
            echo "<tr>
                    <td>{$row['id_pengeluaran']}</td>
                    <td>{$row['tgl_pengeluaran']}</td>
                    <td>" . number_format($row['jumlah'], 0, ',', '.') . "</td>
                    <td>{$row['keterangan']}</td>
                  </tr>";
          }
          echo "<tr>
                  <td colspan='2' class='text-end'><strong>Total Pengeluaran</strong></td>
                  <td colspan='2'><strong>" . number_format($total_pengeluaran, 0, ',', '.') . "</strong></td>
                </tr>";
        } else {
          echo "<tr><td colspan='4' class='text-center'>Tidak ada data pengeluaran untuk bulan ini.</td></tr>";
        }
        ?>
      </tbody>
    </table>

    <!-- Tombol Kembali dan Print PDF -->
    <div class="d-flex justify-content-between mt-4">
      <a href="index.php" class="btn btn-secondary">Kembali ke Beranda</a>
      <a href="laporan-keuangan-pdf.php?bulan=<?php echo $bulan; ?>&tahun=<?php echo $tahun; ?>" class="btn btn-success">Print PDF</a>
    </div>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>