<?php
require 'koneksi.php';
require 'cek-sesi.php';
?>
<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Penggajian Karyawan</title>
    <link rel="icon" href="img/cv_izhar_jaya_mandiri.jpeg" type="image/x-icon">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="vendor/datatables/dataTables.bootstrap4.min.css" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/sweetalert2@11/dist/sweetalert2.min.css">
</head>

<body id="page-top">
    <?php require 'sidebar.php'; ?>

    <div id="content">
        <?php require 'navbar.php'; ?>

        <div class="container-fluid">
            <div class="d-flex align-items-center justify-content-between mb-4">
                <h1 class="h3 mb-0 text-gray-800">Penggajian Karyawan</h1>

                <button type="button" class="btn btn-outline-primary shadow-sm px-3 py-2"
                    data-toggle="modal" data-target="#myModalGaji"
                    style="border-radius: 6px; font-weight: 600; font-size: 14px;">
                    <i class="fas fa-plus"></i> Tambah
                </button>
            </div>

            <!-- Form Filter Tanggal untuk Cetak PDF -->
            <div class="card shadow-sm p-3 mb-4">
                <form method="GET" action="cetak-penggajian.php" target="_blank">
                    <div class="row align-items-center">
                        <div class="col-md-6">
                            <label for="tanggal_filter" class="font-weight-bold">Filter Tanggal:</label>
                            <input type="date" class="form-control" name="tanggal_filter" required>
                        </div>
                        <div class="col-md-3">
                            <button type="submit" class="btn btn-danger btn-block mt-3">
                                <i class="fa fa-file-pdf"></i> Cetak
                            </button>
                        </div>
                    </div>
                </form>
            </div>

            <div class="card shadow mb-4">
                <div class="card-header py-3 d-flex justify-content-between align-items-center">
                    <h6 class="m-0 font-weight-bold text-primary">Daftar Penggajian</h6>
                    <input type="text" id="searchInput" class="form-control w-25" placeholder="Cari..." onkeyup="searchTable()">
                </div>
                <div class="card-body">
                    <div class="table-responsive">
                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                            <thead>
                                <tr>
                                    <th>ID Karyawan</th>
                                    <th>Nama Karyawan</th>
                                    <th>Hari Kerja</th>
                                    <th>Lembur</th>
                                    <th>Jumlah Gaji</th>
                                    <th>Tanggal Pembayaran</th>
                                    <th>Status Pembayaran</th>
                                    <th>Aksi</th>
                                </tr>
                            </thead>
                            <tbody id="tableBody">
                                <?php
                                $query = "SELECT penggajian.*, karyawan.nama FROM penggajian 
                                          JOIN karyawan ON penggajian.id_karyawan = karyawan.id_karyawan";
                                $result = mysqli_query($koneksi, $query);
                                if ($result) {
                                    while ($data = mysqli_fetch_assoc($result)) {
                                ?>
                                        <tr>
                                            <td><?= htmlspecialchars($data['id_karyawan']) ?></td>
                                            <td><?= htmlspecialchars($data['nama']) ?></td>
                                            <td><?= htmlspecialchars($data['jumlah_hari_kerja']) ?></td>
                                            <td><?= htmlspecialchars($data['jumlah_lembur']) ?></td>
                                            <td>Rp<?= number_format($data['jumlah_gaji'], 2, ',', '.') ?></td>
                                            <td><?= htmlspecialchars($data['tanggal_pembayaran']) ?></td>
                                            <td><?= htmlspecialchars($data['status_pembayaran']) ?></td>
                                            <td>
                                                <a href="#" class="btn btn-danger btn-sm" onclick="confirmDelete(<?= $data['id_gaji'] ?>)">Hapus</a>
                                                <a href="#" class="btn btn-info btn-sm" onclick="editPenggajian(<?= $data['id_gaji'] ?>)">Edit</a>
                                                <?php if ($data['status_pembayaran'] === 'Belum') { ?>
                                                    <a href="ubah-status-pembayaran.php?id_gaji=<?= $data['id_gaji'] ?>&status=Sudah" class="btn btn-success btn-sm">Tandai Sudah</a>
                                                <?php } else { ?>
                                                    <a href="ubah-status-pembayaran.php?id_gaji=<?= $data['id_gaji'] ?>&status=Belum" class="btn btn-warning btn-sm">Tandai Belum</a>
                                                <?php } ?>
                                            </td>
                                        </tr>
                                <?php }
                                } else {
                                    echo "<tr><td colspan='8' class='text-center'>Gagal mengambil data penggajian.</td></tr>";
                                } ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <!-- Modal Edit Penggajian -->
            <!-- Modal Form untuk Edit Penggajian Karyawan -->
            <div id="myModalEdit" class="modal fade" role="dialog">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h4 class="modal-title">Edit Penggajian Karyawan</h4>
                            <button type="button" class="close" data-dismiss="modal">&times;</button>
                        </div>
                        <form action="update-penggajian.php" method="post">
                            <div class="modal-body">
                                <input type="hidden" id="id_gaji_edit" name="id_gaji">
                                <label for="id_karyawan_edit">Pilih Karyawan:</label>
                                <select name="id_karyawan" id="id_karyawan_edit" class="form-control" required>
                                    <?php
                                    $query_karyawan = mysqli_query($koneksi, "SELECT id_karyawan, nama FROM karyawan");
                                    while ($karyawan = mysqli_fetch_assoc($query_karyawan)) {
                                        echo '<option value="' . htmlspecialchars($karyawan['id_karyawan']) . '">' . htmlspecialchars($karyawan['nama']) . '</option>';
                                    }
                                    ?>
                                </select>
                                <label for="jumlah_hari_kerja_edit">Hari Kerja:</label>
                                <input type="text" id="jumlah_hari_kerja_edit" name="jumlah_hari_kerja" class="form-control" required>
                                <label for="jumlah_lembur_edit">Lembur:</label>
                                <input type="text" id="jumlah_lembur_edit" name="jumlah_lembur" class="form-control" required>
                                <label for="jumlah_gaji_edit">Jumlah Gaji:</label>
                                <input type="number" id="jumlah_gaji_edit" name="jumlah_gaji" class="form-control" required>
                                <label for="tanggal_pembayaran_edit">Tanggal Pembayaran:</label>
                                <input type="date" id="tanggal_pembayaran_edit" name="tanggal_pembayaran" class="form-control" required>
                            </div>
                            <div class="modal-footer">
                                <button type="submit" class="btn btn-success">Simpan</button>
                                <button type="button" class="btn btn-default" data-dismiss="modal">Keluar</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>

            <!-- JavaScript untuk Fungsionalitas Pencarian -->
            <script>
                function searchTable() {
                    let input = document.getElementById("searchInput");
                    let filter = input.value.toLowerCase();
                    let table = document.getElementById("dataTable");
                    let tr = table.getElementsByTagName("tr");

                    for (let i = 1; i < tr.length; i++) {
                        let td = tr[i].getElementsByTagName("td");
                        let showRow = false;
                        for (let j = 0; j < td.length; j++) {
                            if (td[j]) {
                                let text = td[j].textContent || td[j].innerText;
                                if (text.toLowerCase().indexOf(filter) > -1) {
                                    showRow = true;
                                }
                            }
                        }
                        tr[i].style.display = showRow ? "" : "none";
                    }
                }

                function confirmDelete(id) {
                    Swal.fire({
                        title: 'Apakah Anda yakin?',
                        text: "Data ini akan dihapus!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#d33',
                        cancelButtonColor: '#3085d6',
                        confirmButtonText: 'Ya, hapus!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Arahkan ke halaman PHP untuk menghapus data berdasarkan ID
                            window.location.href = 'hapus-penggajian.php ?id=' + id;
                        }
                    });
                }


                function editPenggajian(id) {
                    // Anda bisa mengambil data untuk diedit dengan menggunakan AJAX atau set nilai dalam form modal langsung
                    $('#myModalEdit').modal('show');
                    $('#id_gaji_edit').val(id);
                }
            </script>
            <!-- Sertakan SweetAlert untuk konfirmasi -->
            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>

            <script>
                function confirmDelete(id) {
                    // Konfirmasi menggunakan SweetAlert
                    Swal.fire({
                        title: 'Apakah Anda yakin?',
                        text: "Data ini akan dihapus!",
                        icon: 'warning',
                        showCancelButton: true,
                        confirmButtonColor: '#d33',
                        cancelButtonColor: '#3085d6',
                        confirmButtonText: 'Ya, hapus!'
                    }).then((result) => {
                        if (result.isConfirmed) {
                            // Mengarahkan ke halaman hapus.php untuk menghapus data
                            window.location.href = 'hapus-penggajian.php?id=' + id;
                        }
                    });
                }
            </script>


        </div>
    </div>

    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
    <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
    <script src="js/sb-admin-2.min.js"></script>
    <script src="vendor/datatables/jquery.dataTables.min.js"></script>
    <script src="vendor/datatables/dataTables.bootstrap4.min.js"></script>
    <script>
        $(document).ready(function() {
            $('#dataTable').DataTable();
        });
    </script>
    <!-- Modal Tambah Penggajian -->
    <div id="myModalGaji" class="modal fade" role="dialog">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h4 class="modal-title">Tambah Penggajian Karyawan</h4>
                    <button type="button" class="close" data-dismiss="modal">&times;</button>
                </div>
                <form action="tambah-penggajian.php" method="post">
                    <div class="modal-body">
                        <!-- Pilih Karyawan -->
                        <label for="id_karyawan">Pilih Karyawan:</label>
                        <select name="id_karyawan" id="id_karyawan" class="form-control" required>
                            <?php
                            $query_karyawan = mysqli_query($koneksi, "SELECT id_karyawan, nama FROM karyawan");
                            while ($karyawan = mysqli_fetch_assoc($query_karyawan)) {
                                echo '<option value="' . htmlspecialchars($karyawan['id_karyawan']) . '">' . htmlspecialchars($karyawan['nama']) . '</option>';
                            }
                            ?>
                        </select>
                        <!-- Hari Kerja -->
                        <label for="jumlah_hari_kerja">Hari Kerja:</label>
                        <input type="text" id="jumlah_hari_kerja" name="jumlah_hari_kerja" class="form-control" required>
                        <!-- Lembur -->
                        <label for="jumlah_lembur">Lembur:</label>
                        <input type="text" id="jumlah_lembur" name="jumlah_lembur" class="form-control" required>
                        <!-- Jumlah Gaji -->
                        <label for="jumlah_gaji">Jumlah Gaji:</label>
                        <input type="number" id="jumlah_gaji" name="jumlah_gaji" class="form-control" required>
                        <!-- Tanggal Pembayaran -->
                        <label for="tanggal_pembayaran">Tanggal Pembayaran:</label>
                        <input type="date" id="tanggal_pembayaran" name="tanggal_pembayaran" class="form-control" required>
                    </div>
                    <div class="modal-footer">
                        <button type="submit" class="btn btn-success">Simpan</button>
                        <button type="button" class="btn btn-default" data-dismiss="modal">Keluar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

</body>

</html>