<?php
include 'koneksi.php'; // Memasukkan koneksi database

// Cek apakah parameter ID ada
if (isset($_GET['id'])) {
    $id = $_GET['id']; // Ambil ID dari URL

    // Query untuk menghapus data berdasarkan ID
    $query = "DELETE FROM penggajian WHERE id_gaji = ?";
    $stmt = $koneksi->prepare($query); // Ganti $conn dengan $koneksi
    if ($stmt === false) {
        die("Terjadi kesalahan dalam persiapan query: " . $koneksi->error);
    }
    $stmt->bind_param("i", $id); // Mengikat parameter ID
    $stmt->execute();

    if ($stmt->affected_rows > 0) {
        echo "<script>alert('Data berhasil dihapus'); window.location.href = 'penggajian.php';</script>";
    } else {
        echo "<script>alert('Data gagal dihapus'); window.location.href = 'penggajian.php';</script>";
    }
}
