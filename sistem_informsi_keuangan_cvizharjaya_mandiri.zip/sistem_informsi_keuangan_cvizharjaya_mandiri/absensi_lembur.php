<?php
// Koneksi ke database
include 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Ambil data dari form
    $id_karyawan = $_POST['id_karyawan'] ?? '';
    $lembur = $_POST['lembur'] ?? 'Tidak';
    $jam_lembur = ($lembur == 'Ya') ? ($_POST['jam_lembur'] ?? '0 Jam') : '0 Jam';
    $keterangan = $_POST['keterangan'] ?? ''; // Ambil keterangan

    // Validasi input
    if (empty($id_karyawan)) {
        echo "<script>
                alert('Pilih karyawan terlebih dahulu!');
                window.location.href = 'absensi_karyawan.php';
              </script>";
        exit;
    }

    // Cek apakah karyawan sudah absen masuk hari ini
    $check_query = "SELECT id_karyawan FROM absensi_karyawan WHERE id_karyawan = ? AND tanggal_masuk = CURDATE()";
    $stmt = mysqli_prepare($koneksi, $check_query);

    if (!$stmt) {
        echo "<script>
                alert('Query error: " . mysqli_error($koneksi) . "');
                window.location.href = 'absensi_karyawan.php';
              </script>";
        exit;
    }

    mysqli_stmt_bind_param($stmt, 'i', $id_karyawan);
    mysqli_stmt_execute($stmt);
    $result = mysqli_stmt_get_result($stmt);

    if (mysqli_num_rows($result) > 0) {
        // Jika sudah ada absensi masuk hari ini, update data lembur dan keterangan
        $update_query = "UPDATE absensi_karyawan
                         SET absen_lembur = ?, jam_lembur = ?, keterangan = ?
                         WHERE id_karyawan = ? AND tanggal_masuk = CURDATE()";
        $stmt_update = mysqli_prepare($koneksi, $update_query);
        mysqli_stmt_bind_param($stmt_update, 'sssi', $lembur, $jam_lembur, $keterangan, $id_karyawan);
        $execute = mysqli_stmt_execute($stmt_update);
    } else {
        // Jika belum ada absensi masuk hari ini, tambahkan data baru
        $insert_query = "INSERT INTO absensi_karyawan (id_karyawan, tanggal_masuk, absen_lembur, jam_lembur, keterangan)
                         VALUES (?, CURDATE(), ?, ?, ?)";
        $stmt_insert = mysqli_prepare($koneksi, $insert_query);
        mysqli_stmt_bind_param($stmt_insert, 'isss', $id_karyawan, $lembur, $jam_lembur, $keterangan);
        $execute = mysqli_stmt_execute($stmt_insert);
    }

    // Cek keberhasilan query
    if ($execute) {
        echo "<script>
                alert('Data lembur berhasil diperbarui!');
                window.location.href = 'absensi_karyawan.php';
              </script>";
    } else {
        echo "<script>
                alert('Gagal memperbarui data lembur: " . mysqli_error($koneksi) . "');
                window.location.href = 'absensi_karyawan.php';
              </script>";
    }
}
