<?php
require 'cek-sesi.php';
require 'koneksi.php';

// Pastikan ID dikirim melalui URL
if (!isset($_GET['nama_suplier']) || empty($_GET['nama_suplier'])) {
    echo "ID tidak ditemukan!";
    exit;
}

$id = mysqli_real_escape_string($koneksi, $_GET['nama_suplier']);

// Hapus data dari database
$query = "DELETE FROM barang_keluar_baru WHERE nama_suplier = '$nama_suplier'";

if (mysqli_query($koneksi, $query)) {
    header("Location: barang_keluar.php?message=Data berhasil dihapus&message_type=success");
    exit;
} else {
    echo "Gagal menghapus data: " . mysqli_error($koneksi);
}
