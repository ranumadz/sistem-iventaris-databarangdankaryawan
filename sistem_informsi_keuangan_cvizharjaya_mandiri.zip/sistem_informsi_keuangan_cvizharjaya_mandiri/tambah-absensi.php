<?php
require 'koneksi.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $id_karyawan = $_POST['id_karyawan'];
    $tanggal_masuk = $_POST['tanggal_masuk'];
    $jam_masuk = $_POST['jam_masuk'];
    $absen_lembur = isset($_POST['absen_lembur']) ? $_POST['absen_lembur'] : 'Tidak';
    $jam_lembur = isset($_POST['jam_lembur']) ? $_POST['jam_lembur'] : null;
    $tanggal_keluar = isset($_POST['tanggal_keluar']) ? $_POST['tanggal_keluar'] : null;
    $jam_keluar = isset($_POST['jam_keluar']) ? $_POST['jam_keluar'] : null;

    // Cek apakah jam masuk valid
    if (!empty($jam_masuk)) {
        $stmt_masuk = $koneksi->prepare("
            INSERT INTO absensi_karyawan 
            (id_karyawan, tanggal_masuk, absen_masuk, absen_lembur, jam_lembur) 
            VALUES (?, ?, ?, ?, ?)
        ");

        if ($stmt_masuk === false) {
            die('Query prepare gagal: ' . $koneksi->error);
        }

        $stmt_masuk->bind_param('sssss', $id_karyawan, $tanggal_masuk, $jam_masuk, $absen_lembur, $jam_lembur);
        $stmt_masuk->execute();
        $stmt_masuk->close();
    }

    // Cek apakah jam keluar valid
    if (!empty($jam_keluar) && !empty($tanggal_keluar)) {
        $stmt_keluar = $koneksi->prepare("
            UPDATE absensi_karyawan 
            SET absen_keluar = ?, tanggal_keluar = ?, jam_keluar = ? 
            WHERE id_karyawan = ? AND tanggal_masuk = ?
        ");

        if ($stmt_keluar === false) {
            die('Query prepare gagal: ' . $koneksi->error);
        }

        $stmt_keluar->bind_param('sssss', $absen_keluar, $tanggal_keluar, $jam_keluar, $id_karyawan, $tanggal_masuk);
        $stmt_keluar->execute();
        $stmt_keluar->close();
    }

    // Kembali ke halaman absensi
    header('Location: absensi_karyawan.php');
    exit();
}
