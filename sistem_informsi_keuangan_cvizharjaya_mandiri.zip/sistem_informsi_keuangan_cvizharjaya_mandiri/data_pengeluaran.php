<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pengeluaran Admin Kedua</title>
    <link rel="stylesheet" href="css/sb-admin-2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <div id="wrapper">
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <li class="nav-item">
                <a class="nav-link" href="data_investor_admin_kedua.php">
                    <i class="fas fa-fw fa-user"></i>
                    <span>Data Investor Admin Kedua</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="data_pengeluaran_admin_kedua.php">
                    <i class="fas fa-fw fa-wallet"></i>
                    <span>Data Pengeluaran Admin Kedua</span>
                </a>
            </li>
        </ul>

        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Data Pengeluaran Admin Kedua</h1>

                    <!-- Form untuk menambah pengeluaran -->
                    <form action="" method="post">
                        <input type="date" name="tgl_pengeluaran" placeholder="Tanggal Pengeluaran" required>
                        <input type="number" name="jumlah" placeholder="Jumlah" required>
                        <input type="number" name="id_sumber" placeholder="ID Sumber" required>
                        <input type="submit" name="tambah_pengeluaran" value="Tambah Pengeluaran">
                    </form>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Daftar Pengeluaran Admin Kedua</h6>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID Pengeluaran</th>
                                        <th>Tanggal Pengeluaran</th>
                                        <th>Jumlah</th>
                                        <th>ID Sumber</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    include 'koneksi_admin_kedua.php'; // Koneksi terpisah

                                    // Proses penambahan pengeluaran
                                    if (isset($_POST['tambah_pengeluaran'])) {
                                        $tgl_pengeluaran = $_POST['tgl_pengeluaran'];
                                        $jumlah = $_POST['jumlah'];
                                        $id_sumber = $_POST['id_sumber'];
                                        mysqli_query($koneksi_admin_kedua, "INSERT INTO pengeluaran_admin_kedua (tgl_pengeluaran, jumlah, id_sumber) VALUES ('$tgl_pengeluaran', '$jumlah', '$id_sumber')");
                                    }

                                    // Tampilkan data pengeluaran dari database admin kedua
                                    $result = mysqli_query($koneksi_admin_kedua, "SELECT * FROM pengeluaran_admin_kedua");
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<tr>
                                        <td>{$row['id_pengeluaran']}</td>
                                        <td>{$row['tgl_pengeluaran']}</td>
                                        <td>{$row['jumlah']}</td>
                                        <td>{$row['id_sumber']}</td>
                                    </tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>