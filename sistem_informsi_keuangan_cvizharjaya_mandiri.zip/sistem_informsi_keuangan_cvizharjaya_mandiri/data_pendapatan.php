<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Data Pendapatan</title>
    <link rel="stylesheet" href="css/sb-admin-2.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
</head>

<body>
    <div id="wrapper">
        <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">
            <li class="nav-item">
                <a class="nav-link" href="data_pemasukan.php">
                    <i class="fas fa-fw fa-money-bill-wave"></i>
                    <span>Data Pendapatan</span>
                </a>
            </li>
            <li class="nav-item">
                <a class="nav-link" href="data_pengeluaran.php">
                    <i class="fas fa-fw fa-wallet"></i>
                    <span>Data Pengeluaran</span>
                </a>
            </li>
        </ul>

        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Data Pendapatan</h1>

                    <!-- Form untuk menambah pendapatan -->
                    <form action="" method="post">
                        <input type="date" name="tgl_pemasukan" placeholder="Tanggal Pemasukan" required>
                        <input type="number" name="jumlah" placeholder="Jumlah" required>
                        <input type="number" name="id_sumber" placeholder="ID Sumber" required>
                        <input type="submit" name="tambah_pemasukan" value="Tambah Pendapatan">
                    </form>

                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Daftar Pendapatan</h6>
                        </div>
                        <div class="card-body">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID Pemasukan</th>
                                        <th>Tanggal Pemasukan</th>
                                        <th>Jumlah</th>
                                        <th>ID Sumber</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php
                                    include 'koneksi.php';

                                    //  penambahan pendapatan
                                    if (isset($_POST['tambah_pemasukan'])) {
                                        $tgl_pemasukan = $_POST['tgl_pemasukan'];
                                        $jumlah = $_POST['jumlah'];
                                        $id_sumber = $_POST['id_sumber'];
                                        mysqli_query($koneksi, "INSERT INTO pemasukan (tgl_pemasukan, jumlah, id_sumber) VALUES ('$tgl_pemasukan', '$jumlah', '$id_sumber')");
                                    }

                                    // data pendapatan
                                    $result = mysqli_query($koneksi, "SELECT * FROM pemasukan");
                                    while ($row = mysqli_fetch_assoc($result)) {
                                        echo "<tr>
                                        <td>{$row['id_pemasukan']}</td>
                                        <td>{$row['tgl_pemasukan']}</td>
                                        <td>{$row['jumlah']}</td>
                                        <td>{$row['id_sumber']}</td>
                                    </tr>";
                                    }
                                    ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@4.5.2/dist/js/bootstrap.bundle.min.js"></script>
</body>

</html>