<?php
require 'koneksi.php';

if (isset($_POST['id_admin'])) {
    $id_admin = $_POST['id_admin'];

    // Menghapus admin dari database
    $query = "DELETE FROM admin WHERE id_admin='$id_admin'";

    if (mysqli_query($koneksi, $query)) {
        // Jika berhasil, arahkan ke halaman kelola-admin.php dengan SweetAlert
        echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
        echo "<script>
                swal({
                    title: 'Berhasil!',
                    text: 'Admin berhasil dihapus!',
                    icon: 'success'
                }).then(function() {
                    window.location.href = 'kelola-admin.php'; // Kembali ke halaman kelola-admin
                });
              </script>";
    } else {
        // Jika gagal, tampilkan alert error
        echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
        echo "<script>
                swal({
                    title: 'Gagal!',
                    text: 'Terjadi kesalahan saat menghapus admin: " . mysqli_error($koneksi) . "',
                    icon: 'error'
                }).then(function() {
                    window.location.href = 'kelola-admin.php'; // Kembali ke halaman kelola-admin
                });
              </script>";
    }
} else {
    // Jika tidak ada id_admin yang diterima
    echo "<script src='https://unpkg.com/sweetalert/dist/sweetalert.min.js'></script>";
    echo "<script>
            swal({
                title: 'Error!',
                text: 'ID Admin tidak ditemukan.',
                icon: 'error'
            }).then(function() {
                window.location.href = 'kelola-admin.php'; // Kembali ke halaman kelola-admin
            });
          </script>";
}
