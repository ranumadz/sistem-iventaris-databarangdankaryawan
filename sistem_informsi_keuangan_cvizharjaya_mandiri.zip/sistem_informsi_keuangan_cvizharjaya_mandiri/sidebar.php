<!-- Page Wrapper -->
<div id="wrapper">

  <!-- Sidebar -->
  <ul class="navbar-nav bg-gradient-primary sidebar sidebar-dark accordion" id="accordionSidebar">

    <!-- Sidebar - Brand Logo -->
    <div class="sidebar-brand d-flex align-items-center justify-content-center">
      <div class="sidebar-brand-icon">
        <!-- Logo Image -->
        <img src="img/logo_cv.jpeg" alt="Logo CV Izhar Mandiri" style="width: 100%; max-width: 150px; height: auto;">
      </div>
    </div>

    <!-- Divider -->
    <hr class="sidebar-divider my-0">

    <!-- Nav Item - Dashboard -->
    <li class="nav-item active">
      <a class="nav-link" href="index.php">
        <i class="fas fa-fw fa-tachometer-alt"></i>
        <span>Dashboard</span></a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
      Transaksi
    </div>

    <!-- Nav Item - Pendapatan -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="pendapatan.php">
        <i class="fas fa-fw fa-arrow-up"></i>
        <span>Pendapatan</span>
      </a>
    </li>

    <!-- Nav Item - Pengeluaran -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="pengeluaran.php">
        <i class="fas fa-fw fa-arrow-down"></i>
        <span>Pengeluaran</span>
      </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <div class="sidebar-heading">
      Data barang
    </div>
    <!-- Tambahan Menu - Barang Masuk -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="barang_masuk.php">
        <i class="fas fa-fw fa-box"></i>
        <span>Barang Masuk</span>
      </a>
    </li>

    <li class="nav-item">
      <a class="nav-link collapsed" href="barang_keluar.php">
        <i class="fas fa-fw fa-box-open"></i>
        <span>Barang Keluar</span>
      </a>
    </li>

    <li class="nav-item">
      <a class="nav-link collapsed" href="data_barang.php">
        <i class="fas fa-fw fa-cogs"></i> <!-- Ganti dengan ikon yang sesuai -->
        <span>Data Barang</span>
      </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
      Karyawan
    </div>

    <!-- Nav Item - Absensi Karyawan -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="absensi_karyawan.php">
        <i class="fas fa-fw fa-users"></i>
        <span>Absensi Karyawan</span>
      </a>
    </li>

    <!-- Nav Item - Karyawan -->
    <li class="nav-item">
      <a class="nav-link collapsed" href="karyawan.php">
        <i class="fas fa-fw fa-users"></i>
        <span>Karyawan</span>
      </a>
    </li>

    <!-- Nav Item - Penggajian Karyawan -->
    <li class="nav-item">
      <a class="nav-link" href="penggajian.php">
        <i class="fas fa-fw fa-dollar-sign"></i>
        <span>Penggajian Karyawan</span>
      </a>
    </li>

    <!-- Divider -->
    <hr class="sidebar-divider">

    <!-- Heading -->
    <div class="sidebar-heading">
      Tagihan
    </div>

    <!-- Nav Item - Hutang -->
    <li class="nav-item">
      <a class="nav-link" href="hutang.php">
        <i class="fas fa-fw fa-chart-area"></i>
        <span>Hutang</span></a>
    </li>

    <!-- Nav Item - Laporan -->
    <li class="nav-item">
      <a class="nav-link" href="laporan.php">
        <i class="fas fa-fw fa-table"></i>
        <span>Laporan</span></a>
    </li>



    <!-- Divider -->
    <hr class="sidebar-divider d-none d-md-block">

    <!-- Sidebar Toggler (Sidebar) -->
    <div class="text-center d-none d-md-inline">
      <button class="rounded-circle border-0" id="sidebarToggle"></button>
    </div>

  </ul>
  <!-- End of Sidebar -->

  <!-- Content Wrapper -->
  <div id="content-wrapper" class="d-flex flex-column">