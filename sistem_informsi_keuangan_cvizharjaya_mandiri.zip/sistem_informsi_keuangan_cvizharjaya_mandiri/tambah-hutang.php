<?php
require 'cek-sesi.php';
require 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $jumlah = mysqli_real_escape_string($koneksi, $_POST['jumlah']);
    $tgl_hutang = mysqli_real_escape_string($koneksi, $_POST['tgl_hutang']);
    $penghutang = mysqli_real_escape_string($koneksi, $_POST['penghutang']);
    $alasan = mysqli_real_escape_string($koneksi, $_POST['alasan']);

    if (empty($jumlah) || empty($tgl_hutang) || empty($penghutang) || empty($alasan)) {
        echo "<script>
            alert('Semua kolom harus diisi!');
            window.location.href='hutang.php';
        </script>";
        exit();
    }

    $query = "INSERT INTO hutang (jumlah, tgl_hutang, penghutang, alasan) VALUES ('$jumlah', '$tgl_hutang', '$penghutang', '$alasan')";

    if (mysqli_query($koneksi, $query)) {
        echo "<script>
            alert('Hutang berhasil ditambahkan!');
            window.location.href='hutang.php';
        </script>";
    } else {
        echo "<script>
            alert('Gagal menambahkan hutang: " . mysqli_error($koneksi) . "');
            window.location.href='hutang.php';
        </script>";
    }
} else {
    echo "<script>
        alert('Akses ditolak!');
        window.location.href='hutang.php';
    </script>";
}
