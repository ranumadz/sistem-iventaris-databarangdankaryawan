<?php
require 'koneksi.php';

// Aktifkan error reporting untuk debugging
error_reporting(E_ALL);
ini_set('display_errors', 1);

$aksi = $_POST['aksi'] ?? $_GET['aksi'] ?? null;

if ($aksi == "tambah") {
    if (
        !empty($_POST['nama_suplier']) && !empty($_POST['nama_barang']) &&
        !empty($_POST['quantity_keluar']) && !empty($_POST['satuan']) &&
        !empty($_POST['harga']) && !empty($_POST['total_harga']) &&
        !empty($_POST['tanggal_keluar']) && isset($_POST['keterangan'])
    ) {
        $nama_suplier = $_POST['nama_suplier'];
        $nama_barang = $_POST['nama_barang'];
        $quantity = (int) $_POST['quantity_keluar'];
        $satuan = $_POST['satuan'];
        $harga = (float) $_POST['harga'];
        $total_harga = (float) $_POST['total_harga'];
        $tanggal_keluar = $_POST['tanggal_keluar'];
        $keterangan = $_POST['keterangan'];

        $query = "INSERT INTO barang_keluar_baru 
            (nama_suplier, nama_barang, quantity_keluar, satuan, harga, total_harga, tanggal_keluar, keterangan) 
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)";

        $stmt = mysqli_prepare($koneksi, $query);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'ssdsdsss', $nama_suplier, $nama_barang, $quantity, $satuan, $harga, $total_harga, $tanggal_keluar, $keterangan);
            $result = mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);

            echo "<script>
                    Swal.fire({
                        icon: 'success',
                        title: 'Berhasil!',
                        text: 'Data berhasil ditambahkan!',
                        showConfirmButton: false,
                        timer: 1500
                    }).then(() => {
                        window.location.href = 'barang_keluar.php';
                    });
                </script>";
        } else {
            echo "Error saat menambahkan data: " . mysqli_error($koneksi);
        }
    } else {
        echo "<script>alert('Data tidak lengkap!');</script>";
    }
}

// ======================= EDIT DATA =======================
if ($aksi == "edit") {
    // Debugging: Cek apakah semua data terkirim
    var_dump($_POST);

    if (
        !empty($_POST['id']) &&
        !empty($_POST['nama_suplier']) && !empty($_POST['nama_barang']) &&
        !empty($_POST['quantity_keluar']) && !empty($_POST['satuan']) &&
        !empty($_POST['harga']) && !empty($_POST['total_harga']) &&
        (isset($_POST['keterangan']) || $_POST['keterangan'] === '')
    ) {
        $id = $_POST['id'];
        $nama_suplier = trim($_POST['nama_suplier']);
        $nama_barang = trim($_POST['nama_barang']);
        $quantity = (int) $_POST['quantity_keluar'];
        $satuan = trim($_POST['satuan']);
        $harga = (float) $_POST['harga'];
        $total_harga = (float) $_POST['total_harga'];
        $keterangan = trim($_POST['keterangan']); // Pastikan tetap menyimpan jika kosong

        // Cek apakah kode_barang ada dalam input
        $kode_barang = isset($_POST['kode_barang']) ? trim($_POST['kode_barang']) : NULL;

        // Query update tanpa mengubah tanggal_keluar
        $query = "UPDATE barang_keluar_baru
                  SET kode_barang=?, nama_suplier=?, nama_barang=?, quantity_keluar=?, satuan=?, harga=?, total_harga=?, keterangan=?
                  WHERE id=?";

        $stmt = mysqli_prepare($koneksi, $query);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'sssssdssi', $kode_barang, $nama_suplier, $nama_barang, $quantity, $satuan, $harga, $total_harga, $keterangan, $id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);
            header("Location: barang_keluar.php?message=Data berhasil diperbarui&message_type=success");
            exit;
        } else {
            die("Error dalam query: " . mysqli_error($koneksi));
        }
    } else {
        echo "Data tidak lengkap untuk diedit!";
    }
}


// ======================= HAPUS DATA =======================

if ($aksi == "hapus") {
    if (!empty($_GET['id'])) {
        $id = $_GET['id'];
        $query = "DELETE FROM barang_keluar_baru WHERE id=?";

        $stmt = mysqli_prepare($koneksi, $query);
        if ($stmt) {
            mysqli_stmt_bind_param($stmt, 'i', $id);
            mysqli_stmt_execute($stmt);
            mysqli_stmt_close($stmt);

            // Simpan pesan ke dalam session agar bisa ditampilkan setelah redirect
            session_start();
            $_SESSION['message'] = "Data berhasil dihapus!";
            $_SESSION['message_type'] = "success";

            // Redirect kembali ke halaman utama
            header("Location: barang_keluar.php");
            exit;
        } else {
            die("Error dalam query: " . mysqli_error($koneksi));
        }
    } else {
        echo "<script>
                Swal.fire({
                    icon: 'error',
                    title: 'Gagal!',
                    text: 'ID tidak ditemukan untuk dihapus!',
                    confirmButtonText: 'OK'
                });
            </script>";
    }
}
