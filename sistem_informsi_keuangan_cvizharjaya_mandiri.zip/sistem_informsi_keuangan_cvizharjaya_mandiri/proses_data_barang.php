<?php
require 'koneksi.php'; // Koneksi ke database

// Menambahkan data barang
if (isset($_POST['tambah_barang'])) {
    $kode_barang = mysqli_real_escape_string($koneksi, $_POST['kode_barang']);
    $nama_barang = mysqli_real_escape_string($koneksi, $_POST['nama_barang']);
    $jumlah_barang = mysqli_real_escape_string($koneksi, str_replace(",", ".", $_POST['jumlah_barang'])); // Ubah koma jadi titik
    $satuan = mysqli_real_escape_string($koneksi, $_POST['satuan']);
    $harga = mysqli_real_escape_string($koneksi, $_POST['harga']);
    $kategori_barang = mysqli_real_escape_string($koneksi, $_POST['kategori_barang']);

    // Query insert data
    $insert_query = "INSERT INTO data_barang (kode_barang, nama_barang, jumlah_barang, satuan, harga, kategori_barang) 
                     VALUES ('$kode_barang', '$nama_barang', '$jumlah_barang', '$satuan', '$harga', '$kategori_barang')";

    if (mysqli_query($koneksi, $insert_query)) {
        header("Location: data_barang.php?message=Data berhasil ditambahkan!");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}


// Proses Edit Barang
if (isset($_POST['edit_barang'])) {
    $id = (int) $_POST['id'];
    $kode_barang = mysqli_real_escape_string($koneksi, $_POST['kode_barang']);
    $nama_barang = mysqli_real_escape_string($koneksi, $_POST['nama_barang']);
    $jumlah_barang = mysqli_real_escape_string($koneksi, str_replace(",", ".", $_POST['jumlah_barang'])); // Ubah koma jadi titik
    $satuan = mysqli_real_escape_string($koneksi, $_POST['satuan']);
    $harga = mysqli_real_escape_string($koneksi, $_POST['harga']);
    $kategori_barang = mysqli_real_escape_string($koneksi, $_POST['kategori_barang']);

    // Query update
    $update_query = "UPDATE data_barang 
                     SET kode_barang = '$kode_barang', 
                         nama_barang = '$nama_barang', 
                         jumlah_barang = '$jumlah_barang', 
                         satuan = '$satuan', 
                         harga = '$harga', 
                         kategori_barang = '$kategori_barang' 
                     WHERE id = $id";

    if (mysqli_query($koneksi, $update_query)) {
        header("Location: data_barang.php?message=Data berhasil diupdate!");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}


// Proses Delete Barang
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id = (int) $_GET['id'];

    $delete_query = "DELETE FROM data_barang WHERE id = $id";

    if (mysqli_query($koneksi, $delete_query)) {
        header("Location: data_barang.php?message=Data berhasil dihapus!");
    } else {
        echo "Error: " . mysqli_error($koneksi);
    }
}
