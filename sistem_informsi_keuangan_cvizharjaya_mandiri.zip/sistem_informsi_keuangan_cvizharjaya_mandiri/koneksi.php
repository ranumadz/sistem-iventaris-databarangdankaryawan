<?php
$host = 'localhost';
$nama = 'root';
$pass = '';
$db = 'cv_izhar_jaya_mandiri';

// Membuat koneksi
$koneksi = mysqli_connect($host, $nama, $pass, $db);

// Cek koneksi
if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}
