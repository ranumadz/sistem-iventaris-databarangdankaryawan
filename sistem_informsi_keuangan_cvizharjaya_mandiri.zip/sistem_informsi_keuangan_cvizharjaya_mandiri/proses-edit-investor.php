<?php
require 'koneksi.php';

$id_investor = $_POST['id_investor'];
$nama_investor = $_POST['nama_investor'];
$jumlah_investasi = $_POST['jumlah_investasi'];
$tanggal_investasi = $_POST['tanggal_investasi'];
$keterangan = $_POST['keterangan'];

$query = "UPDATE investor 
          SET nama_investor = '$nama_investor', jumlah_investasi = '$jumlah_investasi', 
              tanggal_investasi = '$tanggal_investasi', keterangan = '$keterangan' 
          WHERE id_investor = $id_investor";

if (mysqli_query($koneksi, $query)) {
    header("Location: kelola-investor.php");
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
}
