<?php
// Koneksi database
include 'koneksi.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Menangani pendaftaran admin utama
    if (isset($_POST['role']) && $_POST['role'] == 'main') {
        $nama = $_POST['nama'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password

        // Menyimpan admin utama
        $stmt = $pdo->prepare("INSERT INTO admins (nama, email, pass, role) VALUES (?, ?, ?, 'main')");
        $stmt->execute([$nama, $email, $password]);

        echo "Admin utama berhasil ditambahkan!";
    }

    // Menangani pendaftaran admin sekunder
    if (isset($_POST['role']) && $_POST['role'] == 'secondary') {
        $nama = $_POST['nama'];
        $email = $_POST['email'];
        $password = password_hash($_POST['password'], PASSWORD_DEFAULT); // Hash password

        // Menyimpan admin sekunder
        $stmt = $pdo->prepare("INSERT INTO admins (nama, email, pass, role) VALUES (?, ?, ?, 'secondary')");
        $stmt->execute([$nama, $email, $password]);

        echo "Admin sekunder berhasil ditambahkan!";
    }
}
?>

<!-- Form untuk menambah admin -->
<form method="POST">
    <label>Nama:</label>
    <input type="text" name="nama" required>

    <label>Email:</label>
    <input type="email" name="email" required>

    <label>Password:</label>
    <input type="password" name="password" required>

    <label>Role:</label>
    <select name="role">
        <option value="main">Admin Utama</option>
        <option value="secondary">Admin Sekunder</option>
    </select>

    <button type="submit">Tambah Admin</button>
</form>