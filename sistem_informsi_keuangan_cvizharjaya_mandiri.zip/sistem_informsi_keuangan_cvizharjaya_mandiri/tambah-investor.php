<?php
require 'koneksi.php';

$nama_investor = $_POST['nama_investor'];
$jumlah_investasi = $_POST['jumlah_investasi'];
$tanggal_investasi = $_POST['tanggal_investasi'];
$keterangan = $_POST['keterangan'];

$query = "INSERT INTO investor (nama_investor, jumlah_investasi, tanggal_investasi, keterangan) 
          VALUES ('$nama_investor', '$jumlah_investasi', '$tanggal_investasi', '$keterangan')";

if (mysqli_query($koneksi, $query)) {
    header("Location: kelola-investor.php");
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
}
