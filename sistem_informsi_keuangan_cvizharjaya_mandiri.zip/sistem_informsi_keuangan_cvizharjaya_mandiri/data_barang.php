<?php
require 'cek-sesi.php'; // Pastikan sesi valid
require 'koneksi.php'; // Koneksi ke database
require 'sidebar.php'; // Menyertakan sidebar jika ada

// Query untuk mengambil data barang
$search = isset($_GET['search']) ? mysqli_real_escape_string($koneksi, $_GET['search']) : '';
$query = "SELECT * FROM data_barang WHERE nama_barang LIKE '%$search%' OR kode_barang LIKE '%$search%'"; // Pencarian berdasarkan nama dan kode barang
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <title>Data Barang</title>
    <link rel="icon" href="img/cv_izhar_jaya_mandiri.jpeg" type="image/x-icon">
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet" type="text/css">
    <link href="https://fonts.googleapis.com/css?family=Nunito" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <link href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css" rel="stylesheet">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10"></script>
</head>

<body id="page-top">

    <div id="content">
        <?php require 'navbar.php'; ?>
        <div class="container-fluid">
            <!-- Form Pencarian -->
            <form action="data_barang.php" method="GET">
                <div class="input-group mb-3" style="max-width: 300px;"> <!-- Mengatur lebar input -->
                    <input type="text" class="form-control" name="search" placeholder="Cari Barang..." value="<?= isset($_GET['search']) ? htmlspecialchars($_GET['search']) : '' ?>">
                    <div class="input-group-append">
                        <button class="btn btn-primary" type="submit">Cari</button>
                    </div>
                </div>
            </form>


            <!-- Tombol untuk membuka Modal Input -->
            <button class="btn btn-primary" data-toggle="modal" data-target="#inputBarangModal">Input Data Barang</button>
            <a href="cetak_data_barang.php" class="btn btn-success" target="_blank">Cetak PDF</a>

            <!-- Tabel Data Barang -->
            <h2 class="h3 mb-2 text-gray-800 mt-4">Data Barang</h2>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Kode Barang</th>
                        <th>Nama Barang</th>
                        <th>Stock Barang</th>
                        <th>Satuan</th>
                        <th>Harga</th>
                        <th>Kategori Barang</th>
                        <th>Aksi</th>
                    </tr>
                </thead>
                <tbody>
                    <?php if (mysqli_num_rows($result) > 0) {
                        while ($row = mysqli_fetch_assoc($result)) {
                    ?>
                            <tr>
                                <td><?= htmlspecialchars($row['kode_barang']) ?></td>
                                <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                                <td><?= htmlspecialchars($row['jumlah_barang']) ?></td>
                                <td><?= htmlspecialchars($row['satuan']) ?></td>
                                <td>Rp <?= number_format($row['harga'], 0, ',', '.') ?></td>
                                <td><?= htmlspecialchars($row['kategori_barang']) ?></td>
                                <td>
                                    <!-- Button Edit -->
                                    <button class="btn btn-warning" data-toggle="modal" data-target="#editModal<?= $row['id'] ?>">Edit</button>

                                    <!-- Button Delete -->
                                    <button class="btn btn-danger" onclick="confirmDelete(<?= $row['id'] ?>)">Delete</button>

                                    <!-- Modal Edit Barang -->
                                    <div class="modal fade" id="editModal<?= $row['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="editModalLabel<?= $row['id'] ?>" aria-hidden="true">
                                        <div class="modal-dialog" role="document">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title" id="editModalLabel<?= $row['id'] ?>">Edit Data Barang</h5>
                                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                        <span aria-hidden="true">&times;</span>
                                                    </button>
                                                </div>
                                                <div class="modal-body">
                                                    <!-- Form Edit Data Barang -->
                                                    <form action="proses_data_barang.php" method="POST">
                                                        <input type="hidden" name="id" value="<?= $row['id'] ?>">
                                                        <div class="form-group">
                                                            <label for="kode_barang">Kode Barang</label>
                                                            <input type="text" class="form-control" id="kode_barang" name="kode_barang" value="<?= $row['kode_barang'] ?>" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="nama_barang">Nama Barang</label>
                                                            <input type="text" class="form-control" id="nama_barang" name="nama_barang" value="<?= $row['nama_barang'] ?>" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="jumlah_barang">Stock Barang</label>
                                                            <input type="text" class="form-control" id="jumlah_barang" name="jumlah_barang" value="<?= $row['jumlah_barang'] ?>" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="satuan">Satuan</label>
                                                            <select class="form-control" id="satuan" name="satuan" required>
                                                                <option value="kg" <?= $row['satuan'] == 'kg' ? 'selected' : '' ?>>Kilogram (kg)</option>
                                                                <option value="ons" <?= $row['satuan'] == 'ons' ? 'selected' : '' ?>>Ons (ons)</option>
                                                                <option value="pcs" <?= $row['satuan'] == 'pcs' ? 'selected' : '' ?>>Pcs (pcs)</option>
                                                            </select>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="harga">Harga</label>
                                                            <input type="number" class="form-control" id="harga" name="harga" value="<?= $row['harga'] ?>" required>
                                                        </div>
                                                        <div class="form-group">
                                                            <label for="kategori_barang">Kategori Barang</label>
                                                            <select class="form-control" id="kategori_barang" name="kategori_barang" required>
                                                                <option value="plastik" <?= $row['kategori_barang'] == 'plastik' ? 'selected' : '' ?>>Plastik</option>
                                                                <option value="elektronik" <?= $row['kategori_barang'] == 'elektronik' ? 'selected' : '' ?>>Elektronik</option>
                                                            </select>
                                                        </div>
                                                        <button type="submit" class="btn btn-primary" name="edit_barang">Update</button>
                                                    </form>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </td>
                            </tr>
                        <?php }
                    } else { ?>
                        <tr>
                            <td colspan="7">Tidak ada data barang.</td>
                        </tr>
                    <?php } ?>
                </tbody>
            </table>
        </div>
    </div>

    <!-- Modal Input Data Barang -->
    <div class="modal fade" id="inputBarangModal" tabindex="-1" role="dialog" aria-labelledby="inputBarangModalLabel" aria-hidden="true">
        <div class="modal-dialog" role="document">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="inputBarangModalLabel">Tambah Data Barang</h5>
                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span>
                    </button>
                </div>
                <div class="modal-body">
                    <!-- Form Input Data Barang -->
                    <form action="proses_data_barang.php" method="POST">
                        <div class="form-group">
                            <label for="kode_barang">Kode Barang</label>
                            <input type="text" class="form-control" id="kode_barang" name="kode_barang" required>
                        </div>
                        <div class="form-group">
                            <label for="nama_barang">Nama Barang</label>
                            <input type="text" class="form-control" id="nama_barang" name="nama_barang" required>
                        </div>
                        <div class="form-group">
                            <label for="jumlah_barang">Stock Barang</label>
                            <input type="text" class="form-control" id="jumlah_barang" name="jumlah_barang" required>
                        </div>
                        <div class="form-group">
                            <label for="satuan">Satuan</label>
                            <select class="form-control" id="satuan" name="satuan" required>
                                <option value="kg">Kilogram (kg)</option>
                                <option value="ons">Ons (ons)</option>
                                <option value="pcs">Pcs (pcs)</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="harga">Harga</label>
                            <input type="text" class="form-control" id="harga" name="harga" required>
                        </div>
                        <div class="form-group">
                            <label for="kategori_barang">Kategori Barang</label>
                            <select class="form-control" id="kategori_barang" name="kategori_barang" required>
                                <option value="plastik">Plastik</option>
                                <option value="elektronik">Elektronik</option>
                            </select>
                        </div>
                        <button type="submit" class="btn btn-primary" name="tambah_barang">Tambah</button>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <!-- Konfirmasi SweetAlert untuk Delete -->
    <script>
        function confirmDelete(id) {
            Swal.fire({
                title: 'Wah apa beneran mau di hapus nih',
                text: 'Data yang dihapus tidak bisa dikembalikan! Loh',
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#d33',
                cancelButtonColor: '#3085d6',
                confirmButtonText: 'Yes, delete it!'
            }).then((result) => {
                if (result.isConfirmed) {
                    // Redirect ke halaman untuk menghapus data
                    window.location.href = "proses_data_barang.php?action=delete&id=" + id;
                }
            });
        }
    </script>

    <!-- JS Files -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>
</body>

</html>