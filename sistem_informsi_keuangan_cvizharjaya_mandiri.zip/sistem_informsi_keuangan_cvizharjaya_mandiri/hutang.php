<?php
require 'cek-sesi.php';
require 'koneksi.php';
require 'sidebar.php';
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <title>Kelola Hutang</title>
  <link rel="icon" href="img/cv_izhar_jaya_mandiri.jpeg" type="image/x-icon">
  <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
  <link href="css/sb-admin-2.min.css" rel="stylesheet">
  <script src="vendor/jquery/jquery.min.js"></script>
</head>

<body id="page-top">
  <div id="content">
    <?php require 'navbar.php'; ?>
    <div class="container-fluid">
      <h1 class="h3 mb-2 text-gray-800">Hutang</h1>
      <button type="button" class="btn btn-success mb-3" data-toggle="modal" data-target="#myModalTambah">
        <i class="fa fa-plus"></i> Tambah Hutang
      </button>

      <div class="card shadow mb-4">
        <div class="card-header py-3">
          <h6 class="m-0 font-weight-bold text-primary">Daftar Hutang</h6>
        </div>
        <div class="card-body">
          <input type="text" id="searchInput" class="form-control mb-3" placeholder="Cari hutang...">
          <div class="table-responsive">
            <table class="table table-bordered" id="dataTable">
              <thead>
                <tr>
                  <th>No.</th>
                  <th>Nama Suplier</th>
                  <th>Jumlah Hutang</th>
                  <th>Tanggal</th>
                  <th>Alasan</th>
                  <th>Aksi</th>
                </tr>
              </thead>
              <tbody>
                <?php
                $query = mysqli_query($koneksi, "SELECT * FROM hutang ORDER BY tgl_hutang DESC");

                if (!$query) {
                  die("Query Error: " . mysqli_error($koneksi));
                }

                $no = 1;
                while ($data = mysqli_fetch_assoc($query)) {
                  echo "<tr class='hutangRow'>
                                           <td>{$no}</td>
                    <td>{$data['penghutang']}</td>
                    <td>Rp " . number_format($data['jumlah'], 0, ',', '.') . "</td>
                    <td>{$data['tgl_hutang']}</td>
                    <td>{$data['alasan']}</td>
                    <td>
                                                <a href='#' class='fa fa-edit btn btn-primary btn-sm' data-toggle='modal' data-target='#myModal{$data['id_hutang']}'></a>
                                            </td>
                                          </tr>";

                  echo "<div class='modal fade' id='myModal{$data['id_hutang']}' role='dialog'>
                                            <div class='modal-dialog'>
                                                <div class='modal-content'>
                                                    <div class='modal-header'>
                                                        <h4 class='modal-title'>Ubah Data Hutang</h4>
                                                        <button type='button' class='close' data-dismiss='modal'>&times;</button>
                                                    </div>
                                                    <div class='modal-body'>
                                                        <form action='proses-edit-hutang.php' method='post'>
                                                            <input type='hidden' name='id_hutang' value='{$data['id_hutang']}'>
                                                            <div class='form-group'>
                                                                <label>Nama</label>
                                                                <input type='text' name='nama' class='form-control' value='{$data['penghutang']}'>
                                                            </div>
                                                            <div class='form-group'>
                                                                <label>Jumlah</label>
                                                                <input type='date' name='tgl_hutang' class='form-control' value='{$data['jumlah']}'>
                                                            </div>
                                                            <div class='form-group'>
                                                                <label>Tanggal</label>
                                                                <input type='text' name='alasan' class='form-control' value='{$data['tgl_hutang']}'>
                                                            </div>
                                                            <div class='form-group'>
                                                                <label>Alasan</label>
                                                                <input type='text' name='penghutang' class='form-control' value='{$data['alasan']}'>
                                                            </div>
                                                            <div class='modal-footer'>
                                                                <button type='submit' class='btn btn-success'>Ubah</button>
                                                                <a href='hapus-hutang.php?id_hutang={$data['id_hutang']}' onclick='return confirm(\"Anda yakin ingin menghapus?\")' class='btn btn-danger'>Hapus</a>
                                                                <button type='button' class='btn btn-default' data-dismiss='modal'>Keluar</button>
                                                            </div>
                                                        </form>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>";
                  $no++;
                }
                ?>
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  </div>

  <?php require 'footer.php'; ?>

  <div id="myModalTambah" class="modal fade" role="dialog">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h4 class="modal-title">Tambah Hutang</h4>
          <button type="button" class="close" data-dismiss="modal">&times;</button>
        </div>
        <form action="tambah-hutang.php" method="post">
          <div class="modal-body">
            <label>Nama:</label>
            <input type="text" class="form-control" name="penghutang" required>
            <label>Jumlah:</label>
            <input type="number" class="form-control" name="jumlah" required>
            <label>Tanggal:</label>
            <input type="date" class="form-control" name="tgl_hutang" required>
            <label>Alasan:</label>
            <input type="text" class="form-control" name="alasan" required>
          </div>
          <div class="modal-footer">
            <button type="submit" class="btn btn-success">Tambah</button>
            <button type="button" class="btn btn-default" data-dismiss="modal">Keluar</button>
          </div>
        </form>
      </div>
    </div>
  </div>

  <!-- Bootstrap core JavaScript-->
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
  <script src="vendor/jquery-easing/jquery.easing.min.js"></script>
  <script src="js/sb-admin-2.min.js"></script>

  <!-- Pencarian langsung -->
  <script>
    $(document).ready(function() {
      $("#searchInput").on("keyup", function() {
        var value = $(this).val().toLowerCase();
        $(".hutangRow").filter(function() {
          $(this).toggle($(this).text().toLowerCase().indexOf(value) > -1);
        });
      });
    });
  </script>

</body>

</html>