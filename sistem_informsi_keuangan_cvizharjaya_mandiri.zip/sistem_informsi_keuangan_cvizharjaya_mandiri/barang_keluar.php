<?php
require 'cek-sesi.php'; // Pastikan sesi valid
require 'koneksi.php'; // Koneksi ke database
require 'sidebar.php'; // Menyertakan sidebar jika ada

// Ambil data filter tanggal
$filterTanggal = isset($_GET['tanggal_filter']) ? mysqli_real_escape_string($koneksi, $_GET['tanggal_filter']) : date('Y-m-d');

// Buat kondisi query berdasarkan filter
$whereClauses = [];
if ($filterTanggal) {
    $whereClauses[] = "DATE(tanggal_keluar) = '$filterTanggal'";
}

// Gabungkan kondisi filter jika ada
$whereQuery = count($whereClauses) > 0 ? "WHERE " . implode(" AND ", $whereClauses) : "";

// Query untuk mengambil data barang keluar
$query = "SELECT * FROM barang_keluar_baru $whereQuery";
$result = mysqli_query($koneksi, $query);
?>

<!DOCTYPE html>
<html lang="id">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Barang Keluar</title>
    <link href="vendor/fontawesome-free/css/all.min.css" rel="stylesheet">
    <link href="css/sb-admin-2.min.css" rel="stylesheet">
    <script src="vendor/jquery/jquery.min.js"></script>
    <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
</head>

<body id="page-top">
    <div id="wrapper">
        <div id="content-wrapper" class="d-flex flex-column">
            <div id="content">
                <?php include 'navbar.php'; ?>

                <div class="container-fluid">
                    <h1 class="h3 mb-4 text-gray-800">Data Barang Keluar</h1>
                    <form method="GET" action="barang_keluar.php">
                        <div class="row">
                            <div class="col-md-4">
                                <div class="form-group">
                                    <label for="tanggal_filter">Tanggal Keluar</label>
                                    <input type="date" class="form-control" id="tanggal_filter" name="tanggal_filter" value="<?= htmlspecialchars($filterTanggal) ?>">
                                </div>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Filter</button>
                    </form>
                    <br>
                    <button class="btn btn-primary mb-3" data-toggle="modal" data-target="#tambahModal">Tambah Barang Keluar</button>
                    <div class="card shadow mb-4">
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered">
                                    <thead class="thead-dark">
                                        <tr>
                                            <th>No</th>
                                            <th>Nama Suplier</th>
                                            <th>Nama Barang</th>
                                            <th>Jumlah Barang</th>
                                            <th>Satuan</th>
                                            <th>Harga</th>
                                            <th>Total Harga</th>
                                            <th>Keterangan</th>
                                            <th>Tanggal Keluar</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $no = 1;
                                        while ($row = mysqli_fetch_assoc($result)) : ?>
                                            <tr>
                                                <td><?= $no++ ?></td>
                                                <td><?= htmlspecialchars($row['nama_suplier']) ?></td>
                                                <td><?= htmlspecialchars($row['nama_barang']) ?></td>
                                                <td><?= htmlspecialchars($row['quantity_keluar']) ?></td>
                                                <td><?= htmlspecialchars($row['satuan']) ?></td>
                                                <td>Rp <?= number_format(htmlspecialchars($row['harga']), 0, ',', '.') ?></td>
                                                <td>Rp <?= number_format(htmlspecialchars($row['total_harga']), 0, ',', '.') ?></td>
                                                <td><?= htmlspecialchars($row['keterangan']) ?></td>
                                                <td><?= htmlspecialchars($row['tanggal_keluar']) ?></td>
                                                <td>
                                                    <button class="btn btn-warning btn-sm edit-btn"
                                                        data-id="<?= $row['id'] ?>"
                                                        data-suplier="<?= htmlspecialchars($row['nama_suplier']) ?>"
                                                        data-barang="<?= htmlspecialchars($row['nama_barang']) ?>"
                                                        data-quantity="<?= htmlspecialchars($row['quantity_keluar']) ?>"
                                                        data-satuan="<?= htmlspecialchars($row['satuan']) ?>"
                                                        data-harga="<?= htmlspecialchars($row['harga']) ?>"
                                                        data-total="<?= htmlspecialchars($row['total_harga']) ?>"
                                                        data-keterangan="<?= htmlspecialchars($row['keterangan']) ?>">
                                                        Edit
                                                    </button>
                                                    <a href="proses_barang_keluar.php?aksi=hapus&id=<?= $row['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Hapus data ini?');">Hapus</a>
                                                </td>
                                            </tr>
                                        <?php endwhile; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Modal Tambah Barang Keluar -->
                <div class="modal fade" id="tambahModal">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Barang Keluar</h5>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <form action="proses_barang_keluar.php" method="POST">
                                    <input type="hidden" name="aksi" value="tambah">

                                    <div class="form-group">
                                        <label>Nama Suplier</label>
                                        <input type="text" class="form-control" name="nama_suplier" required>
                                    </div>

                                    <div class="form-group">
                                        <label>Nama Barang</label>
                                        <input type="text" class="form-control" name="nama_barang" required>
                                    </div>

                                    <div class="form-group">
                                        <label>Jumlah Barang</label>
                                        <input type="text" class="form-control" name="quantity_keluar" required>
                                    </div>

                                    <div class="form-group">
                                        <label>Satuan</label>
                                        <select class="form-control" name="satuan" required>
                                            <option value="kilogram">Kilogram</option>
                                            <option value="ons">Ons</option>
                                            <option value="pcs">PCS</option>
                                            <!-- Tambahkan opsi lain jika diperlukan -->
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label>Harga</label>
                                        <input type="number" class="form-control" name="harga" required>
                                    </div>

                                    <div class="form-group">
                                        <label>Total Harga</label>
                                        <input type="number" class="form-control" name="total_harga" required>
                                    </div>

                                    <div class="form-group">
                                        <label>Tanggal Keluar</label>
                                        <input type="date" class="form-control" name="tanggal_keluar" required>
                                    </div>

                                    <div class="form-group">
                                        <label>Keterangan</label>
                                        <textarea class="form-control" name="keterangan"></textarea>
                                    </div>

                                    <button type="submit" class="btn btn-primary">Simpan</button>
                                </form>

                            </div>
                        </div>
                    </div>
                </div>

                <div class="modal fade" id="editModal">
                    <div class="modal-dialog">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Barang Keluar</h5>
                                <button type="button" class="close" data-dismiss="modal">&times;</button>
                            </div>
                            <div class="modal-body">
                                <form action="proses_barang_keluar.php" method="POST">
                                    <input type="hidden" name="aksi" value="edit">
                                    <input type="hidden" id="edit-id" name="id">
                                    <div class="form-group">
                                        <label>Nama Suplier</label>
                                        <input type="text" class="form-control" id="edit-suplier" name="nama_suplier" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Nama Barang</label>
                                        <input type="text" class="form-control" id="edit-barang" name="nama_barang" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Jumlah Barang</label>
                                        <input type="text" class="form-control" id="edit-quantity" name="quantity_keluar" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Satuan</label>
                                        <input type="text" class="form-control" id="edit-satuan" name="satuan" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Harga</label>
                                        <input type="number" class="form-control" id="edit-harga" name="harga" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Total Harga</label>
                                        <input type="number" class="form-control" id="edit-total" name="total_harga" required>
                                    </div>
                                    <div class="form-group">
                                        <label>Keterangan</label>
                                        <textarea class="form-control" id="edit-keterangan" name="keterangan"></textarea>
                                    </div>
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>

                <script>
                    $('.edit-btn').click(function() {
                        $('#edit-id').val($(this).data('id'));
                        $('#edit-suplier').val($(this).data('suplier'));
                        $('#edit-barang').val($(this).data('barang'));
                        $('#edit-quantity').val($(this).data('quantity'));
                        $('#edit-satuan').val($(this).data('satuan'));
                        $('#edit-harga').val($(this).data('harga'));
                        $('#edit-total').val($(this).data('total'));
                        $('#edit-keterangan').val($(this).data('keterangan'));
                        $('#editModal').modal('show');
                    });
                </script>
                <script src="vendor/jquery/jquery.min.js"></script>
                <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
                <script>
                    $(document).ready(function() {
                        $('#tambahModal').modal({
                            show: false
                        });

                        $('button[data-target="#tambahModal"]').on('click', function() {
                            $('#tambahModal').modal('show');
                        });
                    });
                </script>
                <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
                <script>
                    document.addEventListener("DOMContentLoaded", function() {
                        const urlParams = new URLSearchParams(window.location.search);
                        const status = urlParams.get("status");

                        if (status === "sukses_tambah") {
                            Swal.fire({
                                icon: "success",
                                title: "Berhasil!",
                                text: "Data berhasil disimpan.",
                                showConfirmButton: false,
                                timer: 2000
                            });
                        } else if (status === "gagal") {
                            Swal.fire({
                                icon: "error",
                                title: "Gagal!",
                                text: "Terjadi kesalahan saat menyimpan data.",
                            });
                        }
                    });
                </script>

            </div>
        </div>
    </div>
</body>

</html>