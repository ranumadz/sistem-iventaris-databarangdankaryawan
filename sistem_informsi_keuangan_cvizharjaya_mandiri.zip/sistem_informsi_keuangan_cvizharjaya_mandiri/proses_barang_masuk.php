<?php
include 'koneksi.php'; // Pastikan koneksi database

$message = ''; // Variabel untuk pesan
$message_type = ''; // Variabel untuk jenis pesan (success, error, warning)

// Periksa apakah metode request adalah POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    if (isset($_POST['id'])) {
        // Proses Edit Data Barang Masuk
        $id_barang = (int) $_POST['id'];
        $kode_barang = mysqli_real_escape_string($koneksi, trim($_POST['kode_barang']));
        $nama_barang = mysqli_real_escape_string($koneksi, trim($_POST['nama_barang']));
        $harga_per_kg = (float) $_POST['harga_per_kg'];
        $satuan = mysqli_real_escape_string($koneksi, trim($_POST['satuan']));

        // Mengganti koma dengan titik pada input untuk quantity_masuk dan total_harga
        $quantity_masuk = (float) str_replace(',', '.', $_POST['quantity_masuk']);
        $total_harga = (float) str_replace(',', '.', $_POST['total_harga']);

        $keterangan = mysqli_real_escape_string($koneksi, trim($_POST['keterangan']));
        // $tanggal_masuk = mysqli_real_escape_string($koneksi, trim($_POST['tanggal_masuk']));

        if ($harga_per_kg > 0 && $quantity_masuk > 0) {
            $query = "UPDATE barang_masuk 
            SET kode_barang='$kode_barang', nama_barang='$nama_barang', harga_per_kg=$harga_per_kg, 
                satuan='$satuan', quantity_masuk=$quantity_masuk, total_harga=$total_harga, 
                keterangan='$keterangan' 
            WHERE id=$id_barang";

            if (mysqli_query($koneksi, $query)) {
                $message = "Data berhasil diperbarui!";
                $message_type = "success";
            } else {
                $message = "Kesalahan saat memperbarui data: " . mysqli_error($koneksi);
                $message_type = "error";
            }
        } else {
            $message = "Harga per Kg dan jumlah barang harus lebih dari 0!";
            $message_type = "warning";
        }
    } elseif (!empty($_POST['nama_barang']) && !empty($_POST['harga_per_kg']) && !empty($_POST['satuan']) && !empty($_POST['quantity_masuk'])) {
        // Proses Tambah Data Barang Masuk
        $kode_barang = mysqli_real_escape_string($koneksi, trim($_POST['kode_barang']));
        $nama_barang = mysqli_real_escape_string($koneksi, trim($_POST['nama_barang']));
        $harga_per_kg = (float) $_POST['harga_per_kg'];
        $satuan = mysqli_real_escape_string($koneksi, trim($_POST['satuan']));

        // Mengganti koma dengan titik pada input untuk quantity_masuk dan total_harga
        $quantity_masuk = (float) str_replace(',', '.', $_POST['quantity_masuk']);
        $total_harga = (float) str_replace(',', '.', $_POST['total_harga']);

        $keterangan = mysqli_real_escape_string($koneksi, trim($_POST['keterangan']));
        $tanggal_masuk = !empty($_POST['tanggal_masuk']) ? mysqli_real_escape_string($koneksi, trim($_POST['tanggal_masuk'])) : date('Y-m-d');

        if ($harga_per_kg > 0 && $quantity_masuk > 0) {
            $query = "INSERT INTO barang_masuk (kode_barang, nama_barang, harga_per_kg, satuan, quantity_masuk, total_harga, tanggal_masuk, keterangan) 
                      VALUES ('$kode_barang', '$nama_barang', $harga_per_kg, '$satuan', $quantity_masuk, $total_harga, '$tanggal_masuk', '$keterangan')";
            if (mysqli_query($koneksi, $query)) {
                $message = "Data berhasil disimpan!";
                $message_type = "success";
            } else {
                $message = "Kesalahan saat menyimpan data: " . mysqli_error($koneksi);
                $message_type = "error";
            }
        } else {
            $message = "Harga per Kg dan jumlah barang harus lebih dari 0!";
            $message_type = "warning";
        }
    }
}

// Periksa penghapusan data (DELETE)
if (isset($_GET['action']) && $_GET['action'] == 'delete' && isset($_GET['id'])) {
    $id_barang = (int) $_GET['id'];

    if ($id_barang > 0) {
        $delete_query = "DELETE FROM barang_masuk WHERE id = $id_barang";

        if (mysqli_query($koneksi, $delete_query)) {
            $message = "Data berhasil dihapus!";
            $message_type = "success";
        } else {
            $message = "Kesalahan saat menghapus data: " . mysqli_error($koneksi);
            $message_type = "error";
        }
    } else {
        $message = "ID barang tidak valid!";
        $message_type = "warning";
    }
}

mysqli_close($koneksi); // Tutup koneksi
?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/sweetalert2@11.6.7/dist/sweetalert2.min.css" rel="stylesheet">
    <title>Proses Barang Masuk</title>
</head>

<body>
    <div class="container mt-5">
        <?php if ($message): ?>
            <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
            <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11.6.7/dist/sweetalert2.all.min.js"></script>
            <script type="text/javascript">
                $(document).ready(function() {
                    <?php if ($message_type == 'success'): ?>
                        Swal.fire({
                            icon: 'success',
                            title: 'Berhasil',
                            text: "<?= $message ?>",
                            showConfirmButton: false,
                            timer: 2000
                        }).then(() => {
                            window.location.href = "barang_masuk.php";
                        });
                    <?php elseif ($message_type == 'error'): ?>
                        Swal.fire({
                            icon: 'error',
                            title: 'Error',
                            text: "<?= $message ?>",
                            showConfirmButton: false,
                            timer: 2000
                        });
                    <?php elseif ($message_type == 'warning'): ?>
                        Swal.fire({
                            icon: 'warning',
                            title: 'Peringatan',
                            text: "<?= $message ?>",
                            showConfirmButton: false,
                            timer: 2000
                        });
                    <?php endif; ?>
                });
            </script>
        <?php endif; ?>
    </div>
</body>

</html>