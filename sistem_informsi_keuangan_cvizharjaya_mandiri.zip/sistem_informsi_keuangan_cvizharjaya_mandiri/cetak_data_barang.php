<?php
ob_start(); // Memulai output buffering

require 'cek-sesi.php'; // Pastikan sesi valid
require 'koneksi.php'; // Koneksi ke database
require 'fpdf/fpdf.php';

// Pastikan koneksi database berhasil
if (!$koneksi) {
    die("Koneksi database gagal: " . mysqli_connect_error());
}

// Ambil data berdasarkan pencarian (jika ada)
$search = isset($_GET['search']) ? mysqli_real_escape_string($koneksi, $_GET['search']) : '';
$query = "SELECT * FROM data_barang WHERE nama_barang LIKE '%$search%' OR kode_barang LIKE '%$search%'";
$result = mysqli_query($koneksi, $query);

// Buat objek FPDF
$pdf = new FPDF('P', 'mm', 'A4');
$pdf->AddPage();
$pdf->SetFont('Arial', 'B', 16);
$pdf->Cell(190, 10, 'Laporan Data Barang', 0, 1, 'C');
$pdf->Ln(5);

// Header tabel
$pdf->SetFont('Arial', 'B', 10);
$pdf->Cell(30, 7, 'Kode Barang', 1, 0, 'C');
$pdf->Cell(50, 7, 'Nama Barang', 1, 0, 'C');
$pdf->Cell(20, 7, 'Stock', 1, 0, 'C');
$pdf->Cell(20, 7, 'Satuan', 1, 0, 'C');
$pdf->Cell(30, 7, 'Harga', 1, 0, 'C');
$pdf->Cell(40, 7, 'Kategori', 1, 1, 'C');

// Cek apakah ada data yang ditemukan
if (mysqli_num_rows($result) > 0) {
    // Isi tabel
    $pdf->SetFont('Arial', '', 10);
    while ($row = mysqli_fetch_assoc($result)) {
        $pdf->Cell(30, 7, $row['kode_barang'], 1, 0, 'C');
        $pdf->Cell(50, 7, $row['nama_barang'], 1, 0, 'L');
        $pdf->Cell(20, 7, $row['jumlah_barang'], 1, 0, 'C');
        $pdf->Cell(20, 7, $row['satuan'], 1, 0, 'C');
        $pdf->Cell(30, 7, 'Rp ' . number_format($row['harga'], 0, ',', '.'), 1, 0, 'R');
        $pdf->Cell(40, 7, $row['kategori_barang'], 1, 1, 'L');
    }
} else {
    // Jika tidak ada data, tampilkan pesan
    $pdf->Cell(190, 7, 'Tidak ada data ditemukan.', 1, 1, 'C');
}

// Hapus output sebelumnya sebelum mengirim PDF
ob_end_clean();
$pdf->Output('D', 'Laporan_Data_Barang.pdf'); // Download otomatis
exit;
