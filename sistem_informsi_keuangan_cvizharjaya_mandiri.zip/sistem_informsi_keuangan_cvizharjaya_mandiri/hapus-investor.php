<?php
require 'koneksi.php';

$id_investor = $_GET['id_investor'];

$query = "DELETE FROM investor WHERE id_investor = $id_investor";

if (mysqli_query($koneksi, $query)) {
    header("Location: kelola-investor.php");
} else {
    echo "Error: " . $query . "<br>" . mysqli_error($koneksi);
}
