<?php
require 'cek-sesi.php';  // Check session to ensure the user is logged in
require 'koneksi.php';   // Database connection

// Get the current date for attendance
$tanggal_masuk = date('Y-m-d');  // Adjust as needed (for example, based on user input)

// Fetch existing attendance data for the day
$id_karyawan = $_SESSION['id_karyawan'];  // Assuming session contains the employee ID
$query = "SELECT * FROM absensi_karyawan WHERE id_karyawan = '$id_karyawan' AND tanggal_masuk = '$tanggal_masuk'";
$result = mysqli_query($koneksi, $query);
$attendance = mysqli_fetch_assoc($result);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // If the form is submitted to record attendance
    $absen_masuk = $_POST['absen_masuk'];
    $jam_masuk = $_POST['jam_masuk'];
    
    if ($attendance) {
        // If attendance already exists for the day, update it
        $query_update = "UPDATE absensi_karyawan 
                         SET absen_masuk = '$absen_masuk', jam_masuk = '$jam_masuk'
                         WHERE id_karyawan = '$id_karyawan' AND tanggal_masuk = '$tanggal_masuk'";
        mysqli_query($koneksi, $query_update);
    } else {
        // If no attendance for the day, insert a new record
        $query_insert = "INSERT INTO absensi_karyawan (id_karyawan, tanggal_masuk, absen_masuk, jam_masuk)
                         VALUES ('$id_karyawan', '$tanggal_masuk', '$absen_masuk', '$jam_masuk')";
        mysqli_query($koneksi, $query_insert);
    }
    
    // Redirect to the same page after submission
    header('Location: absensi_masuk.php');
    exit;
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Absensi Masuk</title>
</head>
<body>
    <h1>Absensi Masuk</h1>
    
    <?php if ($attendance): ?>
        <!-- Display existing attendance data for the day -->
        <p>Attendance already recorded for today:</p>
        <p>Absen Masuk: <?php echo $attendance['absen_masuk']; ?></p>
        <p>Jam Masuk: <?php echo $attendance['jam_masuk']; ?></p>
    <?php else: ?>
        <!-- Form to record attendance -->
        <form action="absensi_masuk.php" method="POST">
            <label for="absen_masuk">Absen Masuk:</label>
            <input type="text" name="absen_masuk" id="absen_masuk" required>
            <br>
            <label for="jam_masuk">Jam Masuk:</label>
            <input type="time" name="jam_masuk" id="jam_masuk" required>
            <br>
            <button type="submit">Record Attendance</button>
        </form>
    <?php endif; ?>
</body>
</html>
